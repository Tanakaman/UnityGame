﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
#if UNITY_EDITOR
    using UnityEditor;
#endif
    using Yggdrasil;

#if UNITY_EDITOR
    public class UnityMenuItemExtension
    {
        [UnityEditor.MenuItem("GameObject/UI/Text(Customized)")]
        public static void CreateCustomizedText()
        {
            GameObject newObject = new GameObject("Text", typeof(UIText));
            newObject.transform.localPosition = Vector3.zero;
            newObject.transform.localScale = Vector3.one;

            string[] fonts = AssetDatabase.FindAssets("t:Font", new string[] { "Assets/DataSources/Fonts" });

            if(fonts != null && fonts.Length > 0)
            {
                var text = newObject.GetComponent<UIText>();
                Font font = AssetDatabase.LoadAssetAtPath<Font>(AssetDatabase.GUIDToAssetPath(fonts[0]));
                text.font = font;
            }

            if(Selection.activeGameObject)
            {
                var parent = Selection.activeGameObject;
                newObject.transform.SetParent(parent.transform, false);
                newObject.tag = parent.tag;
                newObject.layer = parent.layer;
                newObject.isStatic = parent.isStatic;
            }
        }
    }
#endif
}
