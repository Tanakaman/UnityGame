﻿namespace Yggdrasil
{
    using UnityEngine;
    using System;
    using System.Collections;
    using UnityEngine.Assertions;
    using System.Diagnostics;

    public static class Assertion
    {
        /// <summary>
        /// <see cref="self"/>がnullではないことを表します.
        /// </summary>
        /// <param name="self"></param>
        [Conditional("DEBUG")]
        public static void IsNotNull(this Component self)
        {
            UnityEngine.Assertions.Assert.IsNotNull(self);
        }

        [Conditional("DEBUG")]
        public static void IsExpectedToBe<T>(this T self, T expected)
        {
            UnityEngine.Assertions.Assert.AreEqual<T>(expected, self);
        }

        [Conditional("DEBUG")]
        public static void IsExpectedToBeNot<T>(this T self, T expected)
        {
            UnityEngine.Assertions.Assert.AreNotEqual<T>(expected, self);
        }

        //[Conditional("DEBUG")]
        //public static void IsExpectedToBeNot<T>(this T self, T expected, string message)
        //{
        //    UnityEngine.Assertions.Assert.AreNotEqual<T>(expected, self, message);
        //}

        //[Conditional("DEBUG")]
        //public static void IsExpectedToBeNot<T>(this T self, T expected)
        //{
        //    UnityEngine.Assertions.Assert.AreNotEqual<T>(expected, self);
        //}

        [Conditional("DEBUG")]
        public static void IsExpectedToBeNot<T>(this T self, T expected, string message)
        {
            UnityEngine.Assertions.Assert.AreNotEqual<T>(expected, self, message);
        }
    }
}