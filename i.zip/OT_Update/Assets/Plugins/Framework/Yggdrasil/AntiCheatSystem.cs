﻿/// <summary>
/// AntiCheatSystem.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil.AntiCheatSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using UnityEngine;

    /// <summary>
    /// チート対策用クラスを表します.
    /// </summary>
	public sealed class CheckedValue
    {
        /// <summary>
        /// とりあえずの値.
        /// </summary>
        public int Value { get; set; }
    }
}