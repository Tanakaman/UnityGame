﻿/// <summary>
/// ComponentExtension.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;

	public static class ComponentExtension
	{
        /// <summary>
        /// コンポーネントがなければ<see cref="UnityEngine.GameObject.AddComponent{T}"/>を行い、
        /// コンポーネントが存在すれば<see cref="UnityEngine.GameObject.GetComponent{T}"/>を行います.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="self"></param>
        /// <returns></returns>
        public static T RequireComponent<T>(this Component self) where T : Component
        {
            var comp = self.GetComponent<T>();
            if ( comp == null )
            {
                return self.gameObject.AddComponent<T>();
            }
            return comp;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="self"></param>
        public static void DisposeComponent(this Component self)
        {
            MonoBehaviour.Destroy(self);
        }

    }
}