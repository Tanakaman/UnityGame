﻿/// <summary>
/// GameObjectExtension.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;

	public static class GameObjectExtension
	{
        public static void SetLayer(this GameObject self, int layer, bool isChildren = true)
        {
            self.layer = layer;

            if (isChildren)
            {
                var trans = self.transform;
                for (int i = 0; i < trans.childCount; ++i)
                {
                    trans.GetChild(i).gameObject.layer = layer;
                }
            }
        }

        public static T RequireComponent<T>( this GameObject self ) where T : Component
        {
            var _x = self.GetComponent<T>();
            if (_x == null)
            {
                _x = self.AddComponent<T>();
            }
            return _x;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="self"></param>
        public static void DisposeGameObject(this GameObject self)
        {
            MonoBehaviour.Destroy(self);
        }

    }
}
