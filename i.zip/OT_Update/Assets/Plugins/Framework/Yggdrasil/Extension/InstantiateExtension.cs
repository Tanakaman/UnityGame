﻿/// <summary>
/// InstantiateExtension.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;

    public class InstantiateExtension
    {
        public static Object Instantiate(Object original, Transform parent = null)
        {
            var _x = GameObject.Instantiate(original);
            if (_x is GameObject)
            {
                ((GameObject)(_x)).transform.SetParent(parent);
            }
            if (_x is MonoBehaviour)
            {
                ((MonoBehaviour)(_x)).transform.SetParent(parent);
            }
            return _x;
        }
    }
}
