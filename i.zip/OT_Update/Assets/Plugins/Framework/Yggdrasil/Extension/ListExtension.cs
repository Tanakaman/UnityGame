﻿/// <summary>
/// ListExtension.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;
    using System.Collections;
    using System.Collections.Generic;

	public static class ListExtension
	{
        public static List<T> RandomSort<T>(this List<T> self)
        {
            for ( int i = (self.Count-1); i >= 0; --i )
            {
                var idx   = Random.Range(0, self.Count);
                var temp  = self[i];
                self[i]   = self[idx];
                self[idx] = temp;
            }
            return self;
        }
	}
}
