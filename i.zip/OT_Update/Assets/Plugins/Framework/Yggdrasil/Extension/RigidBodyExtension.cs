﻿/// <summary>
/// RigidBodyExtension.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;

    /// <summary>
    /// RigidBodyの拡張メソッドを提供します.
    /// </summary>
	public static class RigidBodyExtension
	{
        /// <summary>
        /// <see cref="UnityEngine.Rigidbody"/>の機能を中断します.
        /// </summary>
        /// <param name="self"></param>
        public static void Pause(this Rigidbody self)
        {
            var resume = self.RequireComponent<RigidBodyResume>();
            resume.Set(self);
            resume.Pause(self);

            self.isKinematic = true;
        }

        /// <summary>
        /// <see cref="UnityEngine.Rigidbody"/>の機能を再開します.
        /// </summary>
        /// <param name="self"></param>
        public static void Resume(this Rigidbody self)
        {
            var resume = self.RequireComponent<RigidBodyResume>();
            resume.Set(self);
            resume.Resume(self);

            self.isKinematic = false;
        }
    }
}
