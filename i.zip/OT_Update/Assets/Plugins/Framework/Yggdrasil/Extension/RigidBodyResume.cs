﻿/// <summary>
/// RigidBodyResume.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;

    /// <summary>
    /// RigidBodyの一時停止機能を提供します.
    /// </summary>
	public class RigidBodyResume : MonoBehaviour
    {
        Rigidbody refRigidBody;

        Vector3 velocity;

        Vector3 angularVelocity;

        public void Set(Rigidbody target)
        {
            if ( this.refRigidBody == target ) return;

            this.refRigidBody = target;
        }

        public void Pause(Rigidbody target)
        {
            this.velocity = target.velocity;
            this.angularVelocity    = target.angularVelocity;
        }

        public void Resume(Rigidbody target)
        {
            target.velocity = this.velocity;
            target.angularVelocity = this.angularVelocity;
        }
    }
}