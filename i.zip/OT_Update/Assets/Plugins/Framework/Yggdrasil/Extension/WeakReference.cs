﻿namespace Yggdrasil
{
    using System;

    /// <summary>
    /// <see cref="T"/>型であることを保証した弱参照を提供します.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [Serializable]
	public sealed class WeakReference<T> : System.WeakReference where T : class
	{
        /// <summary>
        /// 
        /// </summary>
        public WeakReference()
            : base(null)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        public WeakReference(object target)
            : base(target)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="trackResurrection"></param>
        public WeakReference(object target, bool trackResurrection)
            : base(target, trackResurrection)
        {

        }

        /// <summary>
        /// <see cref="T"/>型であることを保証して内包する<see cref="base.Target"/>を返します.
        /// </summary>
        public new T Target
        {
            get { return base.Target as T; }
            set { base.Target = value as T; }
        }
	}
}
