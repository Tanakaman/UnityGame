﻿namespace Yggdrasil
{
    using UnityEngine;
    using System;
    using System.Collections;
    using System.Diagnostics;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// グローバル領域に配置するオブジェクトです.
    /// </summary>
    public sealed class GlobalObject : YggdrasilBegaviour
    {
        /// <summary>
        /// 
        /// </summary>
        void Awake()
        {
            globalObjects.Add(this);
        }

        /// <summary>
        /// 
        /// </summary>
        void Destroy()
        {
            globalObjects.Remove(this);
        }

        /// <summary>
        /// グローバル領域のオブジェクトリスト.
        /// </summary>
        private static List<GlobalObject> globalObjects = new List<GlobalObject>();

    }

    /// <summary>
    /// 
    /// </summary>
    public static partial class Extension
    {
        /// <summary>
        /// グローバル化の設定を行います.
        /// </summary>
        /// <param name="self"></param>
        /// <param name="value"></param>
        public static void SetGlobal(this GameObject self, bool value)
        {
            if (value)
            {
                self.RequireComponent<GlobalObject>();
            }
            else
            {
                self.GetComponents<GlobalObject>().ToList().ForEach( x => x.Dispose() );
            }
        }
    }
}