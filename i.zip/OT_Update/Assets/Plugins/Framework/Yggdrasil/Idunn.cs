﻿/// <summary>
/// Idunn.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;
    using System.Collections;
    using Sound;

    /// <summary>
    /// サウンド関連の処理をまとめるクラスを表します.
    /// </summary>
    public static class Idunn
    {
        static WeakReference<SoundEngine> reference = null;

        public static SoundEngine Instance
        {
            get
            {
                var engine   = Valhalla.GameObject.AddComponent<SoundEngine>();
                reference    = new WeakReference<SoundEngine>(engine);

                return reference.Target;
            }
        }
    }
}