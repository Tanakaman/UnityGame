﻿namespace Yggdrasil
{
    using System;
    using System.Collections.Generic;

	public class Promise<T>
	{
        T result;

        Exception reason;

        PromiseStatus status = PromiseStatus.pending;


        Action<T>         onResolvedHandler = null;
        Action<Exception> onRejectedHandler = null;
        
        /// <summary>
        /// コンストラクタ.
        /// </summary>
        public Promise()
        {
            this.status = PromiseStatus.pending;
        }

        /// <summary>
        /// コンストラクタ.
        /// </summary>
        /// <param name="onExecute"></param>
        public Promise(Action<Action<T> ,Action<Exception>> onExecute)
            : this()
        {
            try
            {
                onExecute(Resolve, Reject);
            }
            catch (Exception e)
            {
                this.status = PromiseStatus.pending;

                Reject(e);
            }
        }

        /// <summary>
        /// Promiseに成功時のハンドラと失敗時のハンドラを渡します.
        /// </summary>
        /// <param name="onResolve">成功時のハンドラ.</param>
        /// <param name="onReject">失敗時のハンドラ.</param>
        /// <returns>解決した新しいPromiseを返します.</returns>
        public Promise<U> Then<U>(
            Func<T,         Promise<U>> onResolve,
            Func<Exception, Promise<U>> onReject)
        {
            var _x = new Promise<U>();

            // pendingされた _x に、thisのハンドラーを渡します.
            this.Handle(
                _onResolve  => onResolve(_onResolve).Handle(_x.Resolve, _x.Reject),
                _onRejected => onReject(_onRejected).Handle(_x.Resolve, _x.Reject)
                    );
            
            return _x;
        }
        
        /// <summary>
        /// Promiseに成功時のハンドラと失敗時のハンドラを渡します.
        /// </summary>
        /// <param name="onResolve">成功時のハンドラ.</param>
        /// <param name="onReject">失敗時のハンドラ.</param>
        /// <returns>解決した新しいPromiseを返します.</returns>
        public Promise<U> Then<U>(
            Func<T,         U         > onResolve,
            Func<Exception, Promise<U>> onReject)
        {
            var _x = new Promise<U>();

            // 成功時のハンドラは引数をそのまま渡します.
            this.Handle(
                _onResolve  => _x.Resolve(onResolve(_onResolve)),
                _onRejected => onReject(_onRejected).Handle(_x.Resolve, _x.Reject)
                    );
            
            return _x;
        }
        
        /// <summary>
        /// Promiseに成功時のハンドラを渡します.
        /// </summary>
        /// <param name="onResolve">付与する成功時のハンドラ.</param>
        /// <returns>解決した新しいPromiseを返します.</returns>
        public Promise<U> Then<U>(
            Func<T,         U         > onResolve)
        {
            var _x = new Promise<U>();

            this.Handle(
                _onResolve  => _x.Resolve(onResolve(_onResolve)),
                _onRejected => _x.Reject(_onRejected)
                    );
            
            return _x;
        }

        /// <summary>
        /// Promiseに失敗時のハンドラを渡します.
        /// </summary>
        /// <param name="onResolve">成功時のハンドラ.</param>
        /// <param name="onReject">失敗時のハンドラ.</param>
        /// <returns>解決した新しいPromiseを返します.</returns>
        //public Promise<U> Then<U>(Func<T, Promise<U>> onResolve)
        //{
        //    var _x = new Promise<U>();

        //    // pendingされた _x に、thisのハンドラーを渡します.
        //    this.Handle(
        //        _onResolve => onResolve(_onResolve).Handle(_x.Resolve, _x.Reject),
        //        _onRejected => _x.Reject(this.reason)
        //            );

        //    return _x;
        //}

        /// <summary>
        /// ハンドラを処理します.
        /// </summary>
        void InvokeHandler()
        {
            Handle(this.onResolvedHandler, this.onRejectedHandler);

            // 1度実行したので使用しない.
            this.onResolvedHandler = null;
            this.onRejectedHandler = null;    
        }

        /// <summary>
        /// 渡されたハンドラの状態を更新します.
        /// </summary>
        /// <param name="onResolve"></param>
        /// <param name="onReject"></param>
        void Handle(Action<T> onResolve, Action<Exception> onReject)
        {
            bool hasResolve = onResolve != null;
            bool hasReject = onReject != null;

            switch (this.status)
            {
                case PromiseStatus.pending:
                    this.onResolvedHandler += onResolve;
                    this.onRejectedHandler += onReject;
                    break;

                case PromiseStatus.fulfilled:
                    try
                    {
                        if (hasResolve) onResolve(this.result);
                    }
                    catch (Exception e)
                    {
                        if (hasReject) onReject(e);
                    }
                    break;

                case PromiseStatus.rejected:
                    if (hasReject) onReject(this.reason);
                    break;
            }
        }

        /// <summary>
        /// 与えられた値で成功となるPromiseオブジェクトを返します.
        /// </summary>
        /// <param name="resolve"></param>
        void Resolve( T resolve )
        {
            if (this.status == PromiseStatus.pending)
            {
                result = resolve;
                this.status = PromiseStatus.fulfilled;
            }
            
            InvokeHandler();
        }

        /// <summary>
        /// 与えられた理由で失敗となるPromiseオブジェクトを返します.
        /// </summary>
        /// <param name="reason"></param>
        void Reject(Exception reason)
        {
            status = PromiseStatus.rejected;
            this.reason = reason;

            InvokeHandler();
        }
	}
}
