﻿/// <summary>
/// PromiseExtension.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using System;

    /// <summary>
    /// <see cref="Yggdrasil.Promise<T>"/>の拡張メソッドを提供します.
    /// </summary>
	public static class PromiseExtension
	{
        /// <summary>
        /// Promiseに成功時のハンドラを渡します.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="promise"></param>
        /// <param name="onResolve"></param>
        /// <returns></returns>
        public static Promise<T> Then<T>(this Promise<T> promise, Func<T, Promise<T>> onResolve)
        {
            return promise.Then<T>(onResolve);
        }

        /// <summary>
        /// Promiseに失敗時のハンドラを渡します.
        /// </summary>
        /// <param name="onReject"></param>
        /// <returns></returns>
        public static Promise<T> Catch<T>(this Promise<T> promise, Action<Exception> onRejected)
        {
            return promise.Then<T>(
                result => result,
                reason =>
                {
                    onRejected(reason);

                    return new Promise<T>((_, reject) =>
                        {
                            reject(reason);
                        });
                });
                
        }
	}
}
