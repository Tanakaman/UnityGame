﻿namespace Yggdrasil
{
    /// <summary>
    /// 
    /// </summary>
	public enum PromiseStatus
    {
        /// <summary>
        /// 初期状態を表します.
        /// </summary>
        pending,

        /// <summary>
        /// 完了したことを表します.
        /// </summary>
        fulfilled,

        /// <summary>
        /// 失敗したことを表します.
        /// </summary>
        rejected
    }
}
