﻿/// <summary>
/// Kongou.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;

    public static class Random
    {
        public static int Range(long min, long max)
        {
            return Range((int)min, (int)max);
        }

        public static int Range(int min, int max)
        {
            return UnityEngine.Random.Range(min, max);
        }

        public static float Range(float min, float max)
        {
            return UnityEngine.Random.Range(min, max);
        }
    }
} 