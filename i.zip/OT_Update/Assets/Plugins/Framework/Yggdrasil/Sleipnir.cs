﻿/// <summary>
/// Idaten.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;
    using System.Collections;
    using System.Collections.Generic;

    /// <summary>
    /// シーン遷移などを行うクラスを表します.
    /// </summary>
    public static class Sleipnir
    {
        public static int CurrentIndex
        {
            get
            {
                return sceneHistory.Count - 1;
            }
        }

        public static string Current
        {
            get
            {
                if (CurrentIndex < 0)
                {
                    return string.Empty;
                }
                return sceneHistory[CurrentIndex];
            }
        }

        /// <summary>
        /// シーンを切り替えます.
        /// </summary>
        /// <param name="name"></param>
        public static void Navigate( string name )
        {
            sceneHistory.Add(name);

            OpenScene(Current);
        }

        /// <summary>
        /// シーンを切り替えます.
        /// </summary>
        public static void NavigatePrev()
        {
            if ( CurrentIndex < 0 )
            {
#if DEBUG_LOG
                Debug.LogWarning("Invalid Index.");
#endif
                return;
            }
            
            sceneHistory.Remove(Current);

            OpenScene(Current);
        }

        /// <summary>
        /// 指定したシーン遷移情報を削除します.
        /// </summary>
        /// <param name="name"></param>
        public static void RemoveScene(string name)
        {
            sceneHistory.Contains(name).IsExpectedToBeNot(true);

            sceneHistory.Remove(name);
        }

        /// <summary>
        /// 指定したシーンへ切り替えます.
        /// </summary>
        /// <param name="name"></param>
        private static void OpenScene(string name)
        {
            //Application.LoadLevel(name);
            UnityEngine.SceneManagement.SceneManager.LoadScene(name);
        }

        private static List<string> sceneHistory = new List<string>();

        /// <summary>
        /// シーン遷移の履歴.
        /// </summary>
        public static List<string> SceneHistory
        {
            get
            {
                List<string> targets = new List<string>();
                {
                    Sleipnir.sceneHistory.ForEach(x => targets.Add(x));
                }
                return targets;
            }
        }
    }
}