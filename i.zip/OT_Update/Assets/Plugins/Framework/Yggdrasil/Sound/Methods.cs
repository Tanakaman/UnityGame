﻿/// <summary>
/// Methods.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil.Sound
{
    using UnityEngine;
    using System.Collections;

    /// <summary>
    /// サウンド処理を提供します.
    /// </summary>
	public static class Methods
	{
        /// <summary>
        /// 対象のBGMを再生します.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static int PlayBGM(string key)
        {
            return Idunn.Instance.PlaySE(key);
        }
        
        /// <summary>
        /// 対象のSEを再生します.
        /// </summary>
        /// <param name="key"></param>
        public static int PlaySE(string key)
        {
            return Idunn.Instance.PlaySE(key);
        }
	}
}
