﻿/// <summary>
/// SoundEngine.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil.Sound
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;

    /// <summary>
    /// サウンド処理を提供します.
    /// </summary>
	public class SoundEngine : MonoBehaviour
	{
        private Dictionary<string, AudioSource> audioSources = new Dictionary<string, AudioSource>();

        /// <summary>
        /// サウンド用ソース.
        /// </summary>
        public Dictionary<string, AudioSource> AudioSources
        {
            get { return audioSources; }
        }

        /// <summary>
        /// 対象のBGMを再生します.
        /// </summary>
        /// <param name="key"></param>
        public int PlayBGM(string key)
        {
            return 0;
        }

        /// <summary>
        /// 対象のSEを再生します.
        /// </summary>
        /// <param name="key"></param>
        public int PlaySE(string key)
        {
            return 0;
        }
	}
}
