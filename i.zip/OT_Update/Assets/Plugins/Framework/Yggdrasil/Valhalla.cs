﻿/// <summary>
/// Tenkai.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Yggdrasil
{
    using UnityEngine;
    using System;
    using System.Collections;

    public static partial class Valhalla
    {
        static GameObject _gameObject = null;

        public static GameObject GameObject
        {
            get
            {
                RequireGameObject();

                return _gameObject;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static void RequireGameObject()
        {
            if (_gameObject != null)
            {
                return;
            }

            var name = typeof(Valhalla).Name;
            GameObject go = new GameObject(name);

            go.transform.SetAsFirstSibling();

            go.SetGlobal(true);

            _gameObject = go;
            _gameObject.IsExpectedToBeNot(null);
        }
    }
}