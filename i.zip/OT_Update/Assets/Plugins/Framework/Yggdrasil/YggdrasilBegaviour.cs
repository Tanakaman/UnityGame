﻿namespace Yggdrasil
{
    using UnityEngine;
    using System.Collections;

    public class YggdrasilBegaviour : MonoBehaviour
    {
        /// <summary>
        /// 自身を<see cref="UnityEngine.Destroy"/>します.
        /// </summary>
        public void Dispose()
        {
            Destroy(this);
        }
    }
}