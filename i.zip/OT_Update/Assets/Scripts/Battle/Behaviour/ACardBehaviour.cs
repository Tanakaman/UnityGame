﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    

    /// <summary>
    /// ゲーム上のカードクラスを表します.
    /// </summary>
    public abstract class ACardBehaviour  : MonoBehaviour, IDisposable
    {
        private ACardViewer viewer;

        public abstract void Dispose();

        public CardStatus Status { get; set; }

        public ACardViewer Viewer { get => viewer; }

        public void Setup(BattleCard target)
        {
            this.Status = new CardStatus();
            
            this.Status.HasCard = target;

            // UIクラスを更新します.
            this.viewer = GetComponent<ACardViewer>();
            if( Viewer )
            {
                this.Viewer.Setup(this.Status);
            }
        }

        private void OnDestroy()
        {
#if DEBUG_LOG
            Debug.Log(this.gameObject.ToString() +  " OnDestroy");
#endif
        }
    }
}
