﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;

    public class BattleCardBehaviour 
        : ACardBehaviour
        , IPointerClickHandler
        , IBeginDragHandler
        , IEndDragHandler
        , IDragHandler
        , IDropHandler
    {
        RectTransform cachedTransform;

        Vector3 prevPosition;

        bool isDragging = false;

        Area parentArea = null;

        DragCardBehaviour cachedDragginComponent = null;

        public Area ParentArea
        {
            get
            {
                return parentArea;
            }

            set
            {
                this.OnParentChanged(value);
            }
        }

        public override void Dispose()
        {
            Destroy(this.gameObject);
        }

        private void OnParentChanged(Area target)
        {
            this.parentArea?.OnReleasedChild();

            this.parentArea = target;

            //this.transform.SetParent(target.transform);
            this.transform.SetParent(BattleInstance.Instance.MonsterPlacementTransform);

            this.SetPositionToParent();
        }

        private void SetPositionToParent()
        {
            if(this.parentArea != null)
            {
                this.cachedTransform.position = this.ParentArea.transform.position;
            }
        }

        private void Awake()
        {
            this.cachedTransform = this.transform as RectTransform;
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            // TODO.
            UIBattleCard.SetSelectCard(this.Status.HasCard);
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            this.prevPosition = this.cachedTransform.position;

            this.isDragging = true;

            //this.cachedDragginComponent = CardCreator.CreateDragCard(this.Status.HasCard, this.transform.parent);
            this.cachedDragginComponent = CardCreator.CreateDragCard(this.Status.HasCard, this.transform);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            this.cachedDragginComponent?.Dispose();

            this.isDragging = false;

#if DEBUG_LOG
            Debug.Log("[BattleCardBehaviour] OnEndDrag");
#endif
        }

        public void OnDrag(PointerEventData e)
        {
            if(!isDragging) return;

            if (cachedDragginComponent != null)
            {
                this.cachedDragginComponent.transform.position += new Vector3(e.delta.x, e.delta.y, 0f);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pointerEventData"></param>
        public void OnDrop(PointerEventData pointerEventData)
        {
            // このキャラクターとのバトル発生.
            BattleCardBehaviour droppedBattleCard = pointerEventData.pointerDrag.GetComponent<BattleCardBehaviour>();
            if (droppedBattleCard)
            {
#if DEBUG_LOG
                Debug.Log("[BattleCardBehaviour] " + droppedBattleCard.Status.HasCard?.Name?.ToString() + " がドロップされました");
                Debug.Log("[BattleCardBehaviour] " + "バトルを開始します.");
#endif

                DamageCalculator.TakeDamage(droppedBattleCard, this);

            }
        }
    }
}
