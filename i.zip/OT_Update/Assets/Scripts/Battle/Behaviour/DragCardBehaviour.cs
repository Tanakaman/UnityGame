﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;

    public class DragCardBehaviour 
        : ACardBehaviour
        , IBeginDragHandler
        , IEndDragHandler
        , IDragHandler
    {
        RectTransform cachedTransform;

        private void Awake()
        {
            this.cachedTransform = this.transform as RectTransform;

            this.transform.SetAsLastSibling();
        }

        private void Start()
        {
            this.cachedTransform.SetAsFirstSibling();
        }

        public override void Dispose()
        {
            Destroy(this.gameObject);
        }

        public void SetParent(Transform parentTrans)
        {

        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            Destroy(this.gameObject);

#if DEBUG_LOG
            Debug.Log("[DragCardBehaviour] OnEndDrag");
#endif
        }

        public void OnDrag(PointerEventData e)
        {
            //this.cachedTransform.position += new Vector3(e.delta.x, e.delta.y, 0f);
        }

    }
}
