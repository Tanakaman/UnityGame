﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;

    public class HandCardBehaviour 
        : ACardBehaviour
        , IPointerClickHandler
        , IBeginDragHandler
        , IEndDragHandler
        , IDragHandler
    {
        RectTransform cachedTransform;

        Vector3 prevPosition;

        bool isDragging = false;

        Area parentArea = null;
        
        DragCardBehaviour cachedDragginComponent = null;

        public Area ParentArea
        {
            get
            {
                return parentArea;
            }

            set
            {
                this.OnParentChanged(value);
            }
        }

        private void OnParentChanged(Area target)
        {
            this.parentArea = target;

            this.SetPositionToParent();
        }

        private void SetPositionToParent()
        {
            if(this.parentArea != null)
            {
                this.cachedTransform.position = this.ParentArea.transform.position;
            }
        }

        private void Awake()
        {
            this.cachedTransform = this.transform as RectTransform;
        }

        public override void Dispose()
        {
            Destroy(this.cachedDragginComponent.gameObject);
            Destroy(this.transform.parent.gameObject);

            // 自身が所持するカードを手札から解除します.
            BattleInstance
                .Instance
                .GetUserData(this.Status.HasCard.HasPlayer)
                .RemoveCard(this.Status.HasCard);
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            // TODO.
            UIBattleCard.SetSelectCard(this.Status.HasCard);
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            this.prevPosition = this.cachedTransform.position;

            this.isDragging = true;

            //this.cachedDragginComponent = CardCreator.CreateDragCard(this.Status.HasCard, this.transform.parent);

            this.cachedDragginComponent = CardCreator.CreateDragCard(
                this.Status.HasCard, 
                BattleInstance.Instance.DragObjectTransform
                );
            this.cachedDragginComponent.transform.position = prevPosition;
#if DEBUG_LOG
            Debug.Log("[HandCardBehaviour] OnBeginDrag");
#endif
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            this.cachedDragginComponent?.Dispose();

            this.isDragging = false;

#if DEBUG_LOG
            Debug.Log("[HandCardBehaviour] OnEndDrag");
#endif
        }

        public void OnDrag(PointerEventData e)
        {
            if (!isDragging) return;

            if (!BattleInstance.Instance.IsMainPhase) return;

            if (cachedDragginComponent != null)
            {
                this.cachedDragginComponent.transform.position += new Vector3(e.delta.x, e.delta.y, 0f);
            }
        }

    }
}
