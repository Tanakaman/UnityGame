﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class BattleCard : Card
    {
        /// <summary>
        /// カードの持ち主を表します.
        /// </summary>
        public Constant.Battle.PlayerSide HasPlayer { get; set; }

    }
}
