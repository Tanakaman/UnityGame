﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// 
    /// </summary>
    public static class BattleCardExtension
    {
        /// <summary>
        /// スペルカードかどうか.
        /// </summary>
        /// <param name="self"></param>
        /// <returns></returns>
        public static bool IsSpellCard(this Card self)
        {
            return self.Type == Constant.Common.CardType.Spell;
        }

        /// <summary>
        /// 指定したタイプの効果が存在するかどうか.
        /// </summary>
        /// <param name="self"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static bool HaveEffect(this Card self, Constant.Battle.EffectType type)
        {
            var fetchEffect = self.EffectSet.Where(x => x.EffectType == Constant.Battle.EffectType.Damage);
            return fetchEffect.ToList().Count > 0;
        }

        /// <summary>
        /// 選択可能効果が存在するかどうか.
        /// </summary>
        /// <param name="self"></param>
        /// <returns></returns>
        public static bool IsSelectableEffect(this Card self)
        {
            var fetchEffect = self.EffectSet.Where(x => x.EffectiveRange == Constant.Battle.EffectRangeType.Single);
            return fetchEffect.ToList().Count > 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="self"></param>
        /// <returns></returns>
        public static bool IsExecutableEffect(this Card self)
        {
            //var areaList = BattleInstance.Instance.Field.BattleAreaAll;

            //// 発動可能かどうかを追記します.
            //if (self.IsSelectableEffect())
            //{


            //    return true;
            //}

            return false;
        }

    }
}
