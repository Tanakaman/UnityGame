﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;

    public static class DamageCalculator
    {
        /// <summary>
        /// キャラクターへダメージを直接与えます.
        /// </summary>
        /// <param name="target"></param>
        /// <param name="damage"></param>
        public static void TakeDamage(BattleCardBehaviour target, long damage)
        {
            TakeDamage(target.Status.HasCard, damage);
            PlayDirection(target.Viewer, damage, null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="attacker"></param>
        /// <param name="defencer"></param>
        public static DamageEventArgment TakeDamage(Card attacker, Card defencer)
        {
            var attackerCard = attacker;
            var attackerHP = attackerCard.HP;
            var attackerPow = attackerCard.Power;

            var currentHP = defencer.HP;
            var currentPow = defencer.Power;

            var damage = attackerPow;

#if DEBUG_LOG
            Debug.Log("[DamageCalculator] " + attacker.Name + " から " + defencer.Name + " にダメージを与えます.");
#endif

            var isDead = TakeDamage(defencer, damage);

            DamageEventArgment result = new DamageEventArgment(null, damage, isDead);

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="attacker"></param>
        /// <param name="defencer"></param>
        public static DamageEventArgment TakeDamage(BattleCardBehaviour attacker, BattleCardBehaviour defencer)
        {
            //BattleInstance.Instance.ControlFilter.SetEnable(true);

            // 防御側に与えるダメージ.
            var result = TakeDamage(attacker.Status.HasCard, defencer.Status.HasCard);

            // 受け手を記憶します.
            result.Target = defencer;

            PlayDirection(defencer.Viewer, result.Damage, () =>
            {
                //BattleInstance.Instance.ControlFilter.SetEnable(false);

                if (result.IsDead)
                {
#if DEBUG_LOG
                    Debug.Log("[DamageCalculator] " + defencer.Status.HasCard.Name + " を倒しました.");
#endif
                    
                }

                // ダメージを与えたことを通知します.
                BattleInstance
                .Instance
                .BattleEvents
                .DamageEventSubject
                .Send(result);

            });

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        private static bool TakeDamage(Card target, long damage)
        {
            var currentHP = target.HP;
            var restHP = currentHP - damage;

            target.HP = restHP < 0 ? 0 : restHP;

#if DEBUG_LOG
            Debug.Log("[DamageCalculator] " + target.Name + " に " + damage.ToString() + " のダメージ.");
#endif

            return target.HP == 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="damage"></param>
        /// <param name="onFinished"></param>
        private static void PlayDirection(ACardViewer target, long damage, Action onFinished)
        {
            DamageDirection.Direction(target, onFinished);
        }
    }
}
