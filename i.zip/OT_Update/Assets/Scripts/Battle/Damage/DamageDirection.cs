﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public static class DamageDirection
    {
        public static void Direction(ACardViewer target, Action onFinished)
        {
            target
                .CharacterImage
                .gameObject
                .AddComponent<UI.TweenAlpha>()
                .Play(0.1f, 0.5f, true)
                .RevertOnFinished()
                .DestroyOnFinished()
                .OnFinished += onFinished;
        }
    }
}
