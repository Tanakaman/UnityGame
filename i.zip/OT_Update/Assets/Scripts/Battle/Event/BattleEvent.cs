﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using OT.Event;

    public interface IEventArgment
    {

    }

    public class PhaseEventArgment : IEventArgment
    {
        public Constant.Battle.PhaseType Type { get; set; }
    }

    public class DamageEventArgment : IEventArgment
    {
        public DamageEventArgment(BattleCardBehaviour target, long damage, bool isDead)
        {
            this.Target = target;
            this.Damage = damage;
            this.IsDead = isDead;
        }

        public BattleCardBehaviour Target { get; set; }

        public long Damage { get; set; }

        public bool IsDead { get; set; }
    }

    public class PlayerStatusArgment : IEventArgment
    {
        public PlayerStatusArgment(Constant.Battle.PlayerEventType EventType, Constant.Battle.PlayerSide Side, int Current, int Max)
        {
            this.EventType = EventType;
            this.Side = Side;
            this.Current = Current;
            this.Max = Max;
        }

        public Constant.Battle.PlayerEventType EventType { get; set; }

        public Constant.Battle.PlayerSide Side { get; set; }

        public int Current { get; set; }
        public int Max { get; set; }
    }

    public class BattleEventSet
    {

        /// <summary>
        /// バトル用初期化イベント通知を表します.
        /// </summary>
        OT.Event.EventSender<Constant.Battle.InitializeType> initializeEventSender = new OT.Event.EventSender<Constant.Battle.InitializeType>();

        /// <summary>
        /// バトル用初期化イベント通知を取得します.
        /// </summary>
        public OT.Event.EventSender<Constant.Battle.InitializeType> InitializeEventSender { get { return initializeEventSender; } }

        /// <summary>
        /// バトル用イベント通知を表します.
        /// </summary>
        OT.Event.EventSender<PhaseEventArgment> phaseEventSender = new OT.Event.EventSender<PhaseEventArgment>();

        /// <summary>
        /// バトル用イベント通知を取得します.
        /// </summary>
        public OT.Event.EventSender<PhaseEventArgment> PhaseEventSender { get { return phaseEventSender; } }

        /// <summary>
        /// ダメージイベントを通知を行います.
        /// </summary>
        OT.Event.EventSender<DamageEventArgment> damageEventSubject = new Event.EventSender<DamageEventArgment>();

        /// <summary>
        /// ダメージイベントを通知を行います.
        /// </summary>
        public EventSender<DamageEventArgment> DamageEventSubject { get => damageEventSubject; }
        
        OT.Event.EventSender<PlayerStatusArgment> playerEventSubject = new EventSender<PlayerStatusArgment>();

        /// <summary>
        /// プレイヤーに関するイベント処理の通知を表します.
        /// </summary>
        public EventSender<PlayerStatusArgment> PlayerEventSubject { get => playerEventSubject; set => playerEventSubject = value; }

    }
}
