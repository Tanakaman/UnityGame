﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;
    using Yggdrasil;

    /// <summary>
    /// バトル中の1エリア単位の処理を提供します.
    /// </summary>
    public class Area 
        : MonoBehaviour
        , IDropHandler
    {
        public Vector2 Position { get; set; }

        Image cachedImage = null;

        BattleCardBehaviour Child { get; set; }

        private void Awake()
        {
            this.cachedImage = this.GetComponent<Image>();
        }

        // 親が変わったときに自身が親ならメンバ変数をnullにします.
        public void OnReleasedChild()
        {
            // TODO . 

            this.Child = null;
        }

        /// <summary>
        /// 配置可能エリアかどうかを表します.
        /// </summary>
        /// <returns></returns>
        private bool IsAvailablePlace(BattleCard target)
        {
            if(target.HasPlayer == Constant.Battle.PlayerSide.Player1)
            {
                if (Position.x == 4 && Position.y == 4)
                {
                    return true;
                }
                if (Position.x == 3 && Position.y == 4)
                {
                    return true;
                }
                if (Position.x == 4 && Position.y == 3)
                {
                    return true;
                }
            }
            else
            {
                if (Position.x == 1 && Position.y == 1)
                {
                    return true;
                }
                if (Position.x == 1 && Position.y == 2)
                {
                    return true;
                }
                if (Position.x == 2 && Position.y == 1)
                {
                    return true;
                }
            }

            return false;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="pointerEventData"></param>
        public void OnDrop(PointerEventData pointerEventData)
        {
            
            BattleCardBehaviour droppedBattleCard = pointerEventData.pointerDrag.GetComponent<BattleCardBehaviour>();
            if(droppedBattleCard)
            {
#if DEBUG_LOG
                Debug.Log("[Area] " + droppedBattleCard.Status.HasCard?.Name?.ToString() + " がドロップされました => " + this.Position.ToString());
#endif
                // このマスにはすでにキャラクターが居るので無効.
                if (this.Child != null)
                {
                    return;
                }

                ChangeBattleCardParent(droppedBattleCard);
            }

            HandCardBehaviour droppedHandCard = pointerEventData.pointerDrag.GetComponent<HandCardBehaviour>();
            if(droppedHandCard)
            {
                var playerSide = droppedHandCard.Status.HasCard.HasPlayer;
#if DEBUG_LOG
                Debug.Log("[Area] " + droppedHandCard.Status.HasCard?.Name?.ToString() + " がドロップされました => " + this.Position.ToString());
#endif

                var inst = BattleInstance.Instance;

                // 手札から配置不可能なエリア.
                if (IsAvailablePlace(droppedHandCard.Status.HasCard) == false)
                {
                    if(droppedHandCard.Status.HasCard.Type == Constant.Common.CardType.Monster)
                    {
                        var argment = new PlayerStatusArgment(
                           Constant.Battle.PlayerEventType.UnavailableSummon,
                           playerSide,
                           0,
                           0);

                        inst.BattleEvents.PlayerEventSubject.Send(argment);

                        return;
                    }
                }

                // このマスにはすでにキャラクターが居るので無効.
                if (this.Child != null)
                {
                    var argment = new PlayerStatusArgment(
                       Constant.Battle.PlayerEventType.UnavailableSummon,
                       playerSide,
                       0,
                       0);

                    inst.BattleEvents.PlayerEventSubject.Send(argment);

                    return;
                }

                var cost = droppedHandCard.Status.HasCard.Cost;
                var playerData  = playerSide == Constant.Battle.PlayerSide.Player1 ? inst.PlayerData : inst.EnemyData;
                var currentMana = playerData.CurrentMana;

                // マナが足りなかったら無効.
                if (currentMana < cost)
                {
                    var argment = new PlayerStatusArgment(
                       Constant.Battle.PlayerEventType.UnavailableSummon,
                       playerSide,
                       0,
                       0);

                    inst.BattleEvents.PlayerEventSubject.Send(argment);

                    return;
                }

                playerData.CurrentMana -= (int)cost;

                // 操作したいカードを生成します.
                BattleCardBehaviour battleCard = CardCreator.CreateBattleCard();

                battleCard.Setup(droppedHandCard.Status.HasCard);

                ChangeBattleCardParent(battleCard);

                // 操作中のカードを破棄します.
                droppedHandCard.Dispose();

                // 召喚成功を通知します.
                {
                    var argment = new PlayerStatusArgment(
                       Constant.Battle.PlayerEventType.Summon,
                       playerSide,
                       0,
                       0);

                    inst.BattleEvents.PlayerEventSubject.Send(argment);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        private void ChangeBattleCardParent(BattleCardBehaviour target)
        {
            target.ParentArea = this;

            this.Child = target;
        }

    }
}
