﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;


    /// <summary>
    /// バトル場のカードを生成するクラスを表します.
    /// </summary>
    public static class CardCreator
    {
        public static GameObject CreateHandCard()
        {
            GameObject cachedResourceGameObject = null;

            if (cachedResourceGameObject == null)
            {
                cachedResourceGameObject = Resources.Load<GameObject>("Card/HandCardObject");
            }

            return MonoBehaviour.Instantiate(cachedResourceGameObject);
        }

        public static BattleCardBehaviour CreateBattleCard()
        {
            GameObject cachedResourceGameObject = null;

            if(cachedResourceGameObject == null)
            {
                cachedResourceGameObject = Resources.Load<GameObject>("Card/FieldCardObject");
            }

            return MonoBehaviour.Instantiate(cachedResourceGameObject).GetComponent<BattleCardBehaviour>();
        }

        //public static DragCardBehaviour CreateDragCard(Transform parentTrans)
        //{
        //    return CreateDragCard(null, parentTrans);
        //}

        public static DragCardBehaviour CreateDragCard(BattleCard card, Transform parentTrans)
        {
            GameObject cachedResourceGameObject = null;

            if(cachedResourceGameObject == null)
            {
                cachedResourceGameObject = Resources.Load<GameObject>("Card/DragFieldCardObject");
            }
            
            DragCardBehaviour behaviour = MonoBehaviour
                .Instantiate(cachedResourceGameObject)
                .GetComponent<DragCardBehaviour>();

            if(card != null) behaviour.Setup(card);

            behaviour.transform.SetParent(parentTrans.parent);
            behaviour.transform.position = parentTrans.position;
            behaviour.transform.SetAsLastSibling();
            return behaviour;
        }
    }
}