﻿namespace OT.Battle
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.IO;
    using UnityEngine;
    using UniRx;
    using MiniJSON;

    public class BattleField : MonoBehaviour
    {
        [SerializeField]
        private Transform rootTrans;

        private void Start()
        {
            this.SubscribeInitializeEvents();

            this.SubscribeDamageEvents();
        }

        private void SubscribeDamageEvents()
        {
            var sender = BattleInstance
                .Instance
                .BattleEvents
                .DamageEventSubject;

            sender
                .OnEvent
                .Where(_ => _.IsDead)
                .Subscribe(OnDead);
        }

        private void SubscribeInitializeEvents()
        {
            var sender = BattleInstance
                .Instance
                .BattleEvents
                .InitializeEventSender;

            sender
                .OnEvent
                .Where(_ => _ == Constant.Battle.InitializeType.FieldBegan)
                .Subscribe(OnInitializeField);

            // カードの召喚を行います.
            sender
                .OnEvent
                .Where(_ => _ == Constant.Battle.InitializeType.SummonBegan)
                .Subscribe(OnInitializeSummon);

            // カードのドローを行います.
            sender
                .OnEvent
                .Where(_ => _ == Constant.Battle.InitializeType.HandBegan)
                .Subscribe(OnInitializeHandCard);

            sender
                .OnEvent
                .Where(_ => _ == Constant.Battle.InitializeType.PlayerDataBegan)
                .Subscribe( _ =>
                {
                    OnInitializePlayerData(_);

                    OnInitializeEnemyData(_);
                });

            sender
                .OnEvent
                .Where(_ => _ == Constant.Battle.InitializeType.Completed)
                .Subscribe(OnCompleted);
        }

        /// <summary>
        /// 死亡イベントが発生したときに呼ばれます.
        /// </summary>
        /// <param name="Argment"></param>
        private void OnDead(DamageEventArgment Argment)
        {
            var hasCard    = Argment.Target.Status.HasCard;
            var playerSide = hasCard.HasPlayer;

            if(playerSide == Constant.Battle.PlayerSide.Player1)
            {
                BattleInstance.Instance.PlayerGraveyard.AddCard(hasCard);
            }
            else
            {
                BattleInstance.Instance.EnemyGraveyard.AddCard(hasCard);
            }

            Argment.Target.Dispose();
        }

        /// <summary>
        /// すべての処理が終了したときに呼ばれます.
        /// </summary>
        /// <param name="Timing"></param>
        private void OnCompleted(Constant.Battle.InitializeType Timing)
        {
#if DEBUG_LOG
            Debug.Log("### バトルを開始します. ###");
#endif
            BattleInstance.Instance.BattlePhaseSequencer.CurrentPhase = Constant.Battle.PhaseType.RefreshBegan;
        }

        /// <summary>
        /// プレイヤーデータを初期化します.
        /// </summary>
        /// <param name="Timing"></param>
        private void OnInitializePlayerData(Constant.Battle.InitializeType Timing)
        {
            var sender = BattleInstance
                .Instance
                .BattleEvents
                .InitializeEventSender;

            BattleInstance.Instance.PlayerDeck = new Deck();

            BattleInstance.Instance.PlayerData.MaxMana = 1;
            BattleInstance.Instance.PlayerData.CurrentMana = 1;
            BattleInstance.Instance.PlayerData.LifePoint = Constant.Battle.LifeMax;
            BattleInstance.Instance.PlayerData.Side = Constant.Battle.PlayerSide.Player1;

            var playerDeck = BattleInstance.Instance.PlayerDeck;

            // ダミーデータのパスを表します.
            var dataPath = Application.streamingAssetsPath + "/DataBase/" + "DummyDeck.json";

            StreamReader sr = new StreamReader(dataPath, Encoding.UTF8);
            var source = sr.ReadToEnd();
            sr.Close();

            // データをテーブルにします.
            var table = Json.Deserialize(source) as IList;

            List<long> monsterIds = new List<long>();
            List<long> spellIds = new List<long>();

            foreach (var t in table)
            {
                var dic = t as IDictionary;
                var id = long.Parse(dic["target_id"] as string);
                var type = long.Parse(dic["card_type"] as string);

                switch ((Constant.Common.CardType)type)
                {
                    case Constant.Common.CardType.Monster:
                        monsterIds.Add(id);
                        break;

                    case Constant.Common.CardType.Spell:
                        spellIds.Add(id);
                        break;
                }

            }

            // マスタデータを取得し、ダミーデータに紐づけてデッキに加えます.
            Model.Master.RequestHelper.GetMasterDataMonster(null, (monsterData) =>
            {
                for (int i = 0; i < monsterIds.Count; ++i)
                {
                    var targetId = monsterIds[i];
                    if (!monsterData.Select(x => x.Id).Contains(targetId)) continue;

                    var card = new BattleCard();
                    card.InitializeMonster(monsterData.Find(x => x.Id == targetId));
                    card.HasPlayer = Constant.Battle.PlayerSide.Player1;

                    // 効果.
                    InitializeCardEffects(card);

                    playerDeck.AddCard(card);
                }

                Model.Master.RequestHelper.GetMasterDataSpell(null, (spellData) =>
                {
                    for (int i = 0; i < spellIds.Count; ++i)
                    {
                        var targetId = spellIds[i];
                        if (!spellData.Select(x => x.Id).Contains(targetId)) continue;

                        var card = new BattleCard();
                        card.InitializeSpell(spellData.Find(x => x.Id == targetId));
                        card.HasPlayer = Constant.Battle.PlayerSide.Player1;

                        // 効果.
                        InitializeCardEffects(card);

                        playerDeck.AddCard(card);
                    }

                    playerDeck.Shuffle();
                    playerDeck.DebugLog();

                    // 終了処理を通知します.
                    //sender.Send(Constant.Battle.InitializeType.PlayerDataFinished);
                });

            });
        }

        /// <summary>
        /// プレイヤーデータを初期化します.
        /// </summary>
        /// <param name="Timing"></param>
        private void OnInitializeEnemyData(Constant.Battle.InitializeType Timing)
        {
            var sender = BattleInstance
                .Instance
                .BattleEvents
                .InitializeEventSender;

            BattleInstance.Instance.EnemyDeck = new Deck();

            BattleInstance.Instance.EnemyData.MaxMana = 1;
            BattleInstance.Instance.EnemyData.CurrentMana = 1;
            BattleInstance.Instance.EnemyData.LifePoint = Constant.Battle.LifeMax;
            BattleInstance.Instance.EnemyData.Side = Constant.Battle.PlayerSide.Player2;

            var enemyDeck = BattleInstance.Instance.EnemyDeck;

            // ダミーデータのパスを表します.
            var dataPath = Application.streamingAssetsPath + "/DataBase/" + "DummyDeck.json";

            StreamReader sr = new StreamReader(dataPath, Encoding.UTF8);
            var source = sr.ReadToEnd();
            sr.Close();

            // データをテーブルにします.
            var table = Json.Deserialize(source) as IList;

            List<long> monsterIds = new List<long>();
            List<long> spellIds = new List<long>();

            foreach (var t in table)
            {
                var dic = t as IDictionary;
                var id = long.Parse(dic["target_id"] as string);
                var type = long.Parse(dic["card_type"] as string);

                switch ((Constant.Common.CardType)type)
                {
                    case Constant.Common.CardType.Monster:
                        monsterIds.Add(id);
                        break;

                    case Constant.Common.CardType.Spell:
                        spellIds.Add(id);
                        break;
                }

            }

            // マスタデータを取得し、ダミーデータに紐づけてデッキに加えます.
            Model.Master.RequestHelper.GetMasterDataMonster(null, (monsterData) =>
            {
                for (int i = 0; i < monsterIds.Count; ++i)
                {
                    var targetId = monsterIds[i];
                    if (!monsterData.Select(x => x.Id).Contains(targetId)) continue;

                    var card = new BattleCard();
                    card.InitializeMonster(monsterData.Find(x => x.Id == targetId));
                    card.HasPlayer = Constant.Battle.PlayerSide.Player2;

                    // 効果.
                    InitializeCardEffects(card);

                    enemyDeck.AddCard(card);
                }

                Model.Master.RequestHelper.GetMasterDataSpell(null, (spellData) =>
                {
                    for (int i = 0; i < spellIds.Count; ++i)
                    {
                        var targetId = spellIds[i];
                        if (!spellData.Select(x => x.Id).Contains(targetId)) continue;

                        var card = new BattleCard();
                        card.InitializeSpell(spellData.Find(x => x.Id == targetId));
                        card.HasPlayer = Constant.Battle.PlayerSide.Player2;

                        // 効果.
                        InitializeCardEffects(card);

                        enemyDeck.AddCard(card);
                    }

                    enemyDeck.Shuffle();
                    enemyDeck.DebugLog();

                    // 終了処理を通知します.
                    sender.Send(Constant.Battle.InitializeType.PlayerDataFinished);
                });

            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        private static void InitializeCardEffects(Card target)
        {
            var idList = target.EffectIdSet;
            Model.Master.RequestHelper.GetMasterDataEffect(idList, (effectData) =>
            {
                target.InitializeEffect(effectData);
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Timing"></param>
        private void OnInitializeHandCard(Constant.Battle.InitializeType Timing)
        {
            var playerData = BattleInstance.Instance.PlayerData;

            playerData.Draw();
            playerData.Draw();
            playerData.Draw();

            var enemyData = BattleInstance.Instance.EnemyData;

            enemyData.Draw();
            enemyData.Draw();
            enemyData.Draw();

            BattleInstance
                    .Instance
                    .BattleEvents
                    .InitializeEventSender
                    .Send(Constant.Battle.InitializeType.HandFinished);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Timing"></param>
        private void OnInitializeField(Constant.Battle.InitializeType Timing)
        {
            FieldCreator.Create(
                this.rootTrans,
                new FieldCreator.CreateParameter(6, 6, new Vector3(1.25f, 1.25f, 1.0f), 130, 130, () =>
                {
                    BattleInstance
                    .Instance
                    .BattleEvents
                    .InitializeEventSender
                    .Send(Constant.Battle.InitializeType.FieldFinished);
                }));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Timing"></param>
        private void OnInitializeSummon(Constant.Battle.InitializeType Timing)
        {
            Debug.Log("OnSummon !!!");
        }

    }
}
