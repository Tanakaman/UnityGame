﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using Yggdrasil;

    /// <summary>
    /// 
    /// </summary>
    public class Deck
    {
        List<BattleCard> cardList = new List<BattleCard>();

        /// <summary>
        /// イベント処理を追加します.
        /// </summary>
        public Deck()
        {

        }

        public BattleCard GetCard(int index)
        {
            return cardList[index];
        }

        public void Shuffle()
        {

        }

        public void DebugLog()
        {
#if DEBUG_LOG

            string debugLog = string.Empty;

            foreach ( var elem in this.cardList )
            {
                debugLog += elem.ToString();
            }

            Debug.Log(debugLog);
#endif
        }

        /// <summary>
        /// カードをデッキに加えます.
        /// </summary>
        /// <param name="target"></param>
        public void AddCard(BattleCard target)
        {
            this.cardList.Add(target);

            OnChangedCardCount(target);
        }

        /// <summary>
        /// カードを一枚引きます.
        /// </summary>
        BattleCard Pop()
        {
            var card = cardList.First();

            cardList.RemoveAt(0);

            OnChangedCardCount(card);

            return card;
        }

        /// <summary>
        /// <see cref="UserData"/>からドローして手札に加えてください.
        /// </summary>
        /// <returns></returns>
        public BattleCard Draw()
        {
            var handCardObj = CardCreator.CreateHandCard();

            var handCard = handCardObj.GetComponentInChildren<HandCardBehaviour>();

            handCard.Setup(Pop());

            if (handCard.Status.HasCard.HasPlayer == Constant.Battle.PlayerSide.Player1)
            {
                // カードを移動させる挙動を行います.
                // とりあえず仮.
                var rootTrans = BattleInstance.Instance.PlayerHandCardRootTransform;
                handCardObj.transform.SetParent(rootTrans);
                handCardObj.transform.localPosition = Vector3.zero;
            }
            else
            {
                // カードを移動させる挙動を行います.
                // とりあえず仮.
                var rootTrans = BattleInstance.Instance.EnemyHandCardRootTransform;
                handCardObj.transform.SetParent(rootTrans);
                handCardObj.transform.localPosition = Vector3.zero;

                // 裏側にします.
                var viewer = handCard.Viewer as HandCardViewer;
                viewer?.SetReverse(true);
            }
            
            return handCard.Status.HasCard;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        private void OnChangedCardCount(BattleCard target)
        {
            var inst = BattleInstance.Instance;

            var argment = new PlayerStatusArgment(
                       Constant.Battle.PlayerEventType.DeckNumChanged,
                       target.HasPlayer,
                       cardList.Count,
                       0);

            inst.BattleEvents.PlayerEventSubject.Send(argment);
        }

    }
}
