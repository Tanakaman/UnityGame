﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;

    
    public static class  FieldCreator
    {
        public class CreateParameter
        {
            public CreateParameter(int sizeX, int sizeY, Vector3 scale, float width, float height, Action onFinished = null)
            {
                this.sizeX = sizeX;
                this.sizeY = sizeY;
                this.scale = scale;
                this.width = width;
                this.height = height;
                this.onFinished = onFinished;
            }

            public int sizeX;
            public int sizeY;
            public Vector3 scale;
            public float width;
            public float height;
            public Action onFinished;
        }

        //private static string GetObjectName(int count, int x, int y)
        //{
        //    return "Tile_" + count.ToString("D2") + "_" + x.ToString() + "_" + y.ToString();
        //}

        public static GameObject LoadObject()
        {
            return Resources.Load<GameObject>("Field/FieldArea");
        }

        public static GameObject CreateObject(GameObject loadedObject)
        {
            var createdObj = GameObject.Instantiate<GameObject>(loadedObject);
            return createdObj;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sizeX"></param>
        /// <param name="sizeY"></param>
        /// <param name="scale"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public static void Create(Transform parentTrans, CreateParameter parameter)
        {
            GameObject loadedObject = null;

            for(int y = 0; y < parameter.sizeX; ++y)
            {
                for(int x = 0; x < parameter.sizeY; ++x)
                {
                    // リーダー配置マス以外を除外します.
                    if(x == 0 && y == 0)
                    {
                        // 相手リーダー.
                    }
                    else if(x == (parameter.sizeY - 1) && y == (parameter.sizeX - 1))
                    {
                        // 自分リーダー.
                    }
                    else if(x == 0)
                    {
                        continue;
                    }
                    else if(y == 0)
                    {
                        continue;
                    }
                    else if(x == (parameter.sizeY - 1))
                    {
                        continue;
                    }
                    else if(y == (parameter.sizeX - 1))
                    {
                        continue;
                    }

                    int count = x + parameter.sizeY * y;

                    // ブロックを生成します.
                    
                    // ブロック単位の位置を調整します.
                    
                    // クォータービュー用.
                    float offsRateX = 0.75f; // 小さいとしきつめる.
                    float offsRateY = 0.75f;

                    // しきつめる.
                    //float offsRateX = 0.5f;
                    //float offsRateY = 0.75f;

                    var posX = x *  parameter.width  * offsRateX - y * parameter.width  * offsRateX;

                    // クォータービュー用アルゴリズム.
                    var posY = y * -parameter.height * offsRateY - x * parameter.height * offsRateY + (parameter.sizeX - 1) * parameter.height * offsRateY;

                    // しきつめるアルゴリズム.
                    //var posY = y * -parameter.height * offsRateY - x * parameter.height * offsRateY + (parameter.sizeX - 1) * parameter.height * offsRateY;
                    
                    // タイル画像をロードします.
                    if(loadedObject == null)
                    {
                        loadedObject = Resources.Load<GameObject>("Field/FieldArea");
                    }

                    var createdObj = GameObject.Instantiate<GameObject>( loadedObject );
                    createdObj.transform.SetParent(parentTrans);

                    // 位置の初期化を行います.
                    {
                        var _area = createdObj.GetComponentInChildren<Area>();
                        _area.Position = new Vector2(x, y);
                    
                        // 画像の設定を行います.
                        {
                            var _image = _area.GetComponent<UnityEngine.UI.Image>();

                            _image.rectTransform.position = Vector3.zero;

                            // クォータービュー.
                            //_image.rectTransform.rotation = Quaternion.Euler(0, 0, 45.0f);

                            //_image.color = (x + y * parameter.sizeX) % 2 == 0 ? Color.red : Color.blue;

                            // 優先度の設定を行います.
                            {
                                //_image.transform.SetAsLastSibling();
                            }
                        }
                    }

                    createdObj.transform.localPosition = new Vector3(posX, posY);
                    createdObj.transform.localScale = parameter.scale;
                }
            }

            if(  parameter.onFinished  != null  ) parameter.onFinished();
        }
    }
}
