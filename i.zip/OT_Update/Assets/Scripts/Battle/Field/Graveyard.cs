﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using Yggdrasil;

    /// <summary>
    /// 
    /// </summary>
    public class Graveyard
    {
        List<BattleCard> cardList = new List<BattleCard>();


        /// <summary>
        /// カードを墓地に加えます.
        /// </summary>
        /// <param name="target"></param>
        public void AddCard(BattleCard target)
        {
            var inst = BattleInstance.Instance;

            this.cardList.Add(target);

            var argment = new PlayerStatusArgment(
                       Constant.Battle.PlayerEventType.GraveyardNumChanged,
                       target.HasPlayer,
                       cardList.Count,
                       0);

            inst.BattleEvents.PlayerEventSubject.Send(argment);
        }
    }
}
