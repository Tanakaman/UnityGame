﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;
    using Yggdrasil;
    using UniRx;

    /// <summary>
    /// 
    /// </summary>
    public class HandCardSorter
        : MonoBehaviour
    {
        [SerializeField]
        Constant.Battle.PlayerSide playerSide;

        [SerializeField]
        float offset = 40;

        private void Start()
        {
            BattleInstance
                .Instance
                .BattleEvents
                .PlayerEventSubject
                .OnEvent
                .Where(_ => _.Side == playerSide && _.EventType == Constant.Battle.PlayerEventType.HandCardNumChanged)
                .Subscribe(arg =>
                {
                    Sort();
                });
        }

        public void Sort()
        {
            var children = this.transform.childCount;

            for ( int i=0; i < children; ++i )
            {
                var child = this.transform.GetChild(i);

                child.transform.localPosition = new Vector3(i * offset, 0, 0);
            }
        }
    }
}
