﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;
    using Yggdrasil;
    using UniRx;

    /// <summary>
    /// 
    /// </summary>
    public class UIBattleCard : UICard
    {
        private static UIBattleCard staticInstace;

        [SerializeField]
        private GameObject uiObjectRoot;

        public static void SetSelectCard(BattleCard target)
        {
            staticInstace.uiObjectRoot.SetActive(target != null);

            if(target != null)staticInstace.SetCardStatus(target);
        }

        private void Awake()
        {
            staticInstace = this;
        }

        private void Start()
        {
            SetSelectCard(null);
        }
    }
}
