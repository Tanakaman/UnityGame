﻿namespace OT.Battle
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;
    using Yggdrasil;
    using UniRx;

    /// <summary>
    /// 
    /// </summary>
    public class UIGraveyard
        : MonoBehaviour
    {

        [SerializeField]
        Text graveyardNumText;

        [SerializeField]
        Constant.Battle.PlayerSide playerSide;


        private void Start()
        {
            BattleInstance
                .Instance
                .BattleEvents
                .PlayerEventSubject
                .OnEvent
                .Where(_ => _.Side == playerSide && _.EventType == Constant.Battle.PlayerEventType.GraveyardNumChanged)
                .Subscribe(arg =>
                {
                    graveyardNumText.text = arg.Current.ToString();
                });
        }

    }
}
