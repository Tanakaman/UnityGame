﻿namespace OT.Battle
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;
    using Yggdrasil;
    using UniRx;

    /// <summary>
    /// 
    /// </summary>
    public class UIMana
        : MonoBehaviour
    {
        [SerializeField]
        List<Image> manaImages = new List<Image>();

        [SerializeField]
        Text currentManaText;

        [SerializeField]
        Text maxManaText;

        [SerializeField]
        Constant.Battle.PlayerSide playerSide;

        /// <summary>
        /// まだ貯まってないときのカラー.
        /// </summary>
        [SerializeField]
        Color deactivatedColor;

        /// <summary>
        /// 現在使用できないカラー.
        /// </summary>
        [SerializeField]
        Color unavailableColor;

        /// <summary>
        /// 現在使用可能なカラー.
        /// </summary>
        [SerializeField]
        Color availableColor;

        private void Start()
        {
            BattleInstance
                .Instance
                .BattleEvents
                .PlayerEventSubject
                .OnEvent
                .Where(_ => _.Side == playerSide && _.EventType == Constant.Battle.PlayerEventType.ManaChanged)
                .Subscribe(arg =>
                {
                    OnChangedMax(arg.Max);

                    OnChangedCurrent(arg.Current);

                });
        }

        void OnChangedCurrent(int value)
        {
            this.currentManaText.text = value.ToString();

            for (int i = 0; i < manaImages.Count; ++i)
            {
                var target = manaImages[i];

                // カラーを変更します.
                target.color = (i < value) ? availableColor : target.color;
            }
        }

        void OnChangedMax(int max)
        {
            this.maxManaText.text = max.ToString();

            for ( int i = 0; i < manaImages.Count; ++i )
            {
                var target = manaImages[i];

                // カラーを変更します.
                {
                    target.color = (i < max) ? unavailableColor : deactivatedColor;
                }
            }

        }

    }
}
