﻿namespace OT.Battle
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;
    using Yggdrasil;
    using UniRx;

    /// <summary>
    /// 
    /// </summary>
    public class UITurnEnd
        : MonoBehaviour
    {
        [SerializeField]
        Text buttonText;

        [SerializeField]
        Constant.Battle.PlayerSide playerSide;

        public void OnTurnEnd()
        {
            var inst = BattleInstance.Instance;

            inst.BattlePhaseSequencer.CurrentPhase = Constant.Battle.PhaseType.TurnFinished;
        }

        private void Start()
        {
            BattleInstance
                .Instance
                .BattleEvents
                .PhaseEventSender
                .OnEvent
                .Where(_ => _.Type == Constant.Battle.PhaseType.MainBegan || _.Type == Constant.Battle.PhaseType.TurnFinished)
                .Subscribe(arg =>
                {
                    buttonText.gameObject.SetActive(BattleInstance.Instance.IsMainPhase);
                });



        }

    }
}
