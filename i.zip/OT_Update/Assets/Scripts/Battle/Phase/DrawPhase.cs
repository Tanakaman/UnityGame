﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// バトル内のフェイズを表します.
    /// </summary>
    public class DrawPhase : APhase
    {
        public override void OnEnter()
        {
            base.OnEnter();

            var inst = BattleInstance.Instance;

            // ドローします.
            if (inst.CurrentSide == Constant.Battle.PlayerSide.Player1)
            {
                var player = inst.PlayerData;
                player.Draw();
            }
            else
            {
                var enemy = inst.EnemyData;
                enemy.Draw();
            }

            inst.BattlePhaseSequencer.CurrentPhase = Constant.Battle.PhaseType.MainBegan;
        }

        public override void OnExit()
        {
            base.OnExit();
        }
    }
}
