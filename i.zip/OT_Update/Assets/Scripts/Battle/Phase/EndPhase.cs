﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// バトル内のフェイズを表します.
    /// </summary>
    public class EndPhase : APhase
    {
        public override void OnEnter()
        {
            base.OnEnter();

            var inst = BattleInstance.Instance;

            // ターンを入れ替え.
            var side = inst.CurrentSide;

            if(side == Constant.Battle.PlayerSide.Player1)
            {
                inst.CurrentSide = Constant.Battle.PlayerSide.Player2;
            }
            else
            {
                inst.CurrentSide = Constant.Battle.PlayerSide.Player1;
            }
            
            inst.BattlePhaseSequencer.CurrentPhase = Constant.Battle.PhaseType.TurnBegan;
            inst.BattlePhaseSequencer.CurrentPhase = Constant.Battle.PhaseType.DrawBegan;
        }
    }
}
