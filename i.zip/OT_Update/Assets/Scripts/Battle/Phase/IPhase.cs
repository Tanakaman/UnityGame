﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public interface IPhase
    {
        void OnEnter();
        void OnExit();
    }

    /// <summary>
    /// バトル内のフェイズを表します.
    /// </summary>
    public abstract class APhase : IPhase
    {


        public virtual void OnEnter()
        {

        }

        public virtual void OnExit()
        {

        }
    }
}
