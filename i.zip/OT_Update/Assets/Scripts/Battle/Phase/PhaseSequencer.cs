﻿namespace OT.Battle
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UniRx;
    using UnityEngine;

    /// <summary>
    /// バトル内のフェイズを表します.
    /// </summary>
    public class PhaseSequencer
    {
        Constant.Battle.PhaseType currentPhase = Constant.Battle.PhaseType.None;
        public Constant.Battle.PhaseType CurrentPhase
        {
            get => currentPhase;

            set
            {
                OnPhaseFinished();

                currentPhase = value;

#if DEBUG_LOG
                Debug.Log("[PhaseSequencer] フェイズが切り替わりました. => " + this.currentPhase.ToString());
#endif
                this.OnPhaseBegan();
            }
        }

        Dictionary<Constant.Battle.PhaseType, APhase> Phase = new Dictionary<Constant.Battle.PhaseType, APhase>();

        //Subject<Constant.Battle.PhaseType> PhaseSubject = new Subject<Constant.Battle.PhaseType>();

        void OnPhaseFinished()
        {
            if (!this.Phase.ContainsKey(CurrentPhase)) return;

            APhase phase = this.Phase[CurrentPhase];
            phase.OnExit();
        }

        void OnPhaseBegan()
        {
            PhaseEventArgment argment = new PhaseEventArgment();
            argment.Type = CurrentPhase;

            BattleInstance
                .Instance
                .BattleEvents
                .PhaseEventSender
                .Send(argment);

            // TODO : 以下はSubscribeするようにリファクタ.
            if (!this.Phase.ContainsKey(CurrentPhase)) return;

            APhase phase = this.Phase[CurrentPhase];
            phase.OnEnter();
        }


        public PhaseSequencer()
        {
            Phase.Add(Constant.Battle.PhaseType.PlayerInitialized, new InitializePhase());
            Phase.Add(Constant.Battle.PhaseType.RefreshBegan,      new RefreshPhase());
            Phase.Add(Constant.Battle.PhaseType.DrawBegan,         new DrawPhase());
            Phase.Add(Constant.Battle.PhaseType.MainBegan,         new BattlePhase());
            Phase.Add(Constant.Battle.PhaseType.TurnFinished,      new EndPhase());
            //Phase.Add(Constant.Battle.PhaseType.PlayerInitialized, new ResultPhase());

            //CurrentPhase = Constant.Battle.PhaseType.PlayerInitialized;
        }

        
    }
}
