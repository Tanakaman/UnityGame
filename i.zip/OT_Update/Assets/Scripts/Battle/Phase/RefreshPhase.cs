﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// バトル内のフェイズを表します.
    /// </summary>
    public class RefreshPhase : APhase
    {
        public override void OnEnter()
        {
            base.OnEnter();

            var inst = BattleInstance.Instance;

            // ターン数をカウントします.
            inst.TurnCount += 1;

            inst.BattlePhaseSequencer.CurrentPhase = Constant.Battle.PhaseType.DrawBegan;
        }

    }
}
