﻿namespace OT.Battle
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UniRx;

    /// <summary>
    /// バトルを初期化します.
    /// </summary>
    public class BattleInitializer : MonoBehaviour
    {
        private void Awake()
        {
            DeveloperTools
                .DeveloperToolInitializer
                .Initialize();
        }

        public void StartInitialize()
        {
            StartCoroutine(InitialFade(() =>
            {
                // とりあえず直列処理します.
                InitializeArea( () => 
                {
                    InitializePlayersData(() =>
                    {
                        InitializePlayersHandCard(() =>
                        {
                            InitializeCompleted();
                        });
                    });
                } );
            }));
        }

        private IEnumerator InitialFade(Action onFinihsed)
        {
            yield return null;

            onFinihsed();

            yield break;
        }

        /// <summary>
        /// 
        /// </summary>
        private void InitializeCompleted()
        {
            var sender = BattleInstance
                    .Instance
                    .BattleEvents
                    .InitializeEventSender;

            sender.Send(Constant.Battle.InitializeType.Completed);
        }

        /// <summary>
        /// プレイヤーデータの初期化を行います.
        /// </summary>
        /// <param name="onFinished"></param>
        private void InitializePlayersData(Action onFinished)
        {
            DebugLog("プレイヤーのデッキなど", isFinished: false);

            var sender = BattleInstance
                    .Instance
                    .BattleEvents
                    .InitializeEventSender;


            // 終了メッセージを登録します.
            sender
                .OnEvent
                .Where(_ => _ == Constant.Battle.InitializeType.PlayerDataFinished)
                .Subscribe(_ =>
                {
                    DebugLog("プレイヤーのデッキなど", isFinished: true);

                    onFinished();
                });


            sender.Send(Constant.Battle.InitializeType.PlayerDataBegan);
        }

        /// <summary>
        /// プレイヤーデータの初期化を行います.
        /// </summary>
        /// <param name="onFinished"></param>
        private void InitializePlayersHandCard(Action onFinished)
        {
            DebugLog("プレイヤーのカード", isFinished: false);

            var sender = BattleInstance
                    .Instance
                    .BattleEvents
                    .InitializeEventSender;


            // 終了メッセージを登録します.
            sender
                .OnEvent
                .Where(_ => _ == Constant.Battle.InitializeType.HandFinished)
                .Subscribe(_ =>
                {
                    DebugLog("プレイヤーのカード", isFinished: true);

                    onFinished();
                });


            sender.Send(Constant.Battle.InitializeType.HandBegan);
        }

        /// <summary>
        /// エリアの初期化処理を行います.
        /// </summary>
        /// <param name="onFinished"></param>
        private void InitializeArea(Action onFinished)
        {
            DebugLog("バトルのエリア", isFinished: false);

            var sender = BattleInstance
                    .Instance
                    .BattleEvents
                    .InitializeEventSender;

            // 終了メッセージを登録して.
            sender
                .OnEvent
                .Where(_ => _ == Constant.Battle.InitializeType.FieldFinished)
                .Subscribe(_ =>
                {
                    DebugLog("バトルのエリア", isFinished: true);

                    onFinished();
                });

            // フィールドの初期化メッセージを送ります.
            sender.Send(Constant.Battle.InitializeType.FieldBegan);
            
        }

        [System.Diagnostics.Conditional("DEBUG_LOG")] 
        private void DebugLog(string log, bool isFinished)
        {
#if DEBUG_LOG
            Debug.Log("[BattleInitializer] " + log + "の初期化を" + (!isFinished ? "開始します" : "完了しました"));
#endif
        }

    }
}
