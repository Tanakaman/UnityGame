﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;

    /// <summary>
    /// バトル中に使用するインスタンスをキャッシュします.
    /// </summary>
    public class BattleInstance : MonoBehaviour
    {
        /// <summary>
        /// シングルトンを表します.
        /// </summary>
        public static BattleInstance Instance { get; set; }

        UserData playerData = new UserData();

        /// <summary>
        /// プレイヤーのデータを表します.
        /// </summary>
        public UserData PlayerData { get { return playerData; } }

        UserData enemyData = new UserData();

        /// <summary>
        /// 敵プレイヤーのデータを表します.
        /// </summary>
        public UserData EnemyData { get { return enemyData; } }

        BattleEventSet battleEvents = new BattleEventSet();

        /// <summary>
        /// 
        /// </summary>
        public BattleEventSet BattleEvents { get => battleEvents; set => battleEvents = value; }

        [SerializeField]
        private Transform backgroundUITransform;

        /// <summary>
        /// 
        /// </summary>
        public Transform BackgroundUITransform {  get { return backgroundUITransform; } }

        [SerializeField]
        private Transform middlegroundUITransform;

        /// <summary>
        /// 
        /// </summary>
        public Transform MiddlegroundUITransform { get { return middlegroundUITransform; } }

        [SerializeField]
        private Transform playerHandCardRootTransform;

        /// <summary>
        /// 
        /// </summary>
        public Transform PlayerHandCardRootTransform { get => playerHandCardRootTransform; set => playerHandCardRootTransform = value; }

        [SerializeField]
        private Transform enemyHandCardRootTransform;

        /// <summary>
        /// 
        /// </summary>
        public Transform EnemyHandCardRootTransform { get => enemyHandCardRootTransform; set => enemyHandCardRootTransform = value; }

        [SerializeField]
        private Transform monsterPlacementTransform;

        /// <summary>
        /// 
        /// </summary>
        public Transform MonsterPlacementTransform { get => monsterPlacementTransform;  }

        [SerializeField]
        private Transform dragObjectTransform;

        /// <summary>
        /// 
        /// </summary>
        public Transform DragObjectTransform { get => dragObjectTransform; }

        [SerializeField]
        private BattleInitializer initializer;

        /// <summary>
        /// 
        /// </summary>
        public BattleInitializer Initializer { get => initializer; }

        private PhaseSequencer battlePhaseSequencer = new PhaseSequencer();

        /// <summary>
        /// 
        /// </summary>
        public PhaseSequencer BattlePhaseSequencer { get => battlePhaseSequencer; set => battlePhaseSequencer = value; }
        
        private Deck playerDeck = null;

        /// <summary>
        /// 
        /// </summary>
        public Deck PlayerDeck { get => playerDeck; set => playerDeck = value; }
        
        private Graveyard playerGraveyard = new Graveyard();

        /// <summary>
        /// 
        /// </summary>
        public Graveyard PlayerGraveyard { get => playerGraveyard; set => playerGraveyard = value; }

        private Deck enemyDeck = null;

        /// <summary>
        /// 
        /// </summary>
        public Deck EnemyDeck { get => enemyDeck; set => enemyDeck = value; }

        private Graveyard enemyGraveyard = new Graveyard();

        /// <summary>
        /// 
        /// </summary>
        public Graveyard EnemyGraveyard { get => enemyGraveyard; set => enemyGraveyard = value; }

        /// <summary>
        /// ユーザーの情報を取得します.
        /// </summary>
        /// <param name="side"></param>
        /// <returns></returns>
        public UserData GetUserData(Constant.Battle.PlayerSide side)
        {
            if(side == Constant.Battle.PlayerSide.Player1)
            {
                return this.playerData;
            }
            else
            {
                return this.enemyData;
            }
        }

        /// <summary>
        /// ユーザーの情報を取得します.
        /// </summary>
        /// <param name="side"></param>
        /// <returns></returns>
        public Deck GetDeck(Constant.Battle.PlayerSide side)
        {
            if (side == Constant.Battle.PlayerSide.Player1)
            {
                return this.playerDeck;
            }
            else
            {
                return this.enemyDeck;
            }
        }

        /// <summary>
        /// ユーザーの情報を取得します.
        /// </summary>
        /// <param name="side"></param>
        /// <returns></returns>
        public Graveyard GetGraveyard(Constant.Battle.PlayerSide side)
        {
            if (side == Constant.Battle.PlayerSide.Player1)
            {
                return this.PlayerGraveyard;
            }
            else
            {
                return this.EnemyGraveyard;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsMainPhase
        {
            get
            {
                return this.BattlePhaseSequencer.CurrentPhase == Constant.Battle.PhaseType.MainBegan &&
                       this.CurrentSide == Constant.Battle.PlayerSide.Player1;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public int TurnCount { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        Constant.Battle.PlayerSide side;

        /// <summary>
        /// 今どちらのプレイヤーのターンかを表します.
        /// </summary>
        public Constant.Battle.PlayerSide CurrentSide
        {
            get => side;
            set
            {
                side = value;

#if DEBUG_LOG
                Debug.Log("[BattleInstance] ターンが切り替わりました => " + side.ToString());
#endif
            }
        }

        private void Awake()
        {
            Instance = this;
        }

        private void Start()
        {
            this.BattlePhaseSequencer.CurrentPhase = Constant.Battle.PhaseType.PlayerInitialized;
        }
    }
}
