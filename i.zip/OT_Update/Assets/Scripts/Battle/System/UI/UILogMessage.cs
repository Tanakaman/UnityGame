﻿
namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UnityEngine;
    using UnityEngine.UI;
    using UniRx;

    public class UILogMessage : MonoBehaviour
    {
        private static UILogMessage privateInst;

        [SerializeField]
        Text messageText;

        [SerializeField]
        private int logCountMax = 20;

        List<string> log = new List<string>();

        void Awake()
        {
            privateInst = this;
        }

        private void Start()
        {
            var events = BattleInstance
                .Instance
                .BattleEvents;

            events
                .PlayerEventSubject
                .OnEvent
                .Where(_ => _.EventType == Constant.Battle.PlayerEventType.Summon)
                .Subscribe(_ =>
                {
                    Request("モンスターが召喚されました");
                });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public static void Request(string message)
        {
            privateInst.Play(message);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        private void Play(string text)
        {
            string message = string.Empty;

            //for (int i = 0; i < 30; ++i)
            //{
            this.log.Add(text);
            //}

            if(this.log.Count >= logCountMax)
            {
                this.log.RemoveAt(0);
            }

            for ( int i = 0; i < this.log.Count; ++i )
            {
                message += log[i] + "\n";
            }

            this.messageText.text = message;
        }
    }
}
