﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UnityEngine;
    using UnityEngine.UI;
    using UniRx;

    public class UISystemMessage : MonoBehaviour
    {
        private static UISystemMessage privateInst;

        [SerializeField]
        Text messageText;

        [SerializeField]
        UI.TweenAlpha tweenaAlpha;

        void Awake()
        {
            privateInst = this;
        }

        private void Start()
        {
            var events = BattleInstance
                .Instance
                .BattleEvents;

            events
                .PlayerEventSubject
                .OnEvent
                .Where(_ => _.EventType == Constant.Battle.PlayerEventType.UnavailableSummon)
                .Subscribe(_ =>
                {
                    Request("召喚できませんでした");
                });

            events
                .PhaseEventSender
                .OnEvent
                .Subscribe(_ => 
                {
                    
                });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public static void Request(string message)
        {
            privateInst.Play(message);
        }

        private void Play(string text)
        {
            this.messageText.text = text;
            this.messageText.gameObject.SetActive(true);
            this.tweenaAlpha
                .Play(1, 0, 0.5f, 0.5f)
                .SetDelay(1)
                .OnFinished = () =>
                {
                    var color = this.messageText.color;
                    color.a = 1;
                    this.messageText.color = color;
                    this.messageText.gameObject.SetActive(false);
                };
        }
    }
}
