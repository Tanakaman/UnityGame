﻿namespace OT.Battle.Task
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UniRx;
    using UnityEngine;

    public class BattleTaskScheduler : MonoBehaviour
    {
        private Subject<BattleTask> requestedTaskSubject = new Subject<BattleTask>();

        public IObservable<BattleTask> OnTaskRequested
        {
            get { return this.requestedTaskSubject; }
        }

        private Subject<BattleTask> broadcastTaskSubject = new Subject<BattleTask>();

        public IObservable<BattleTask> OnTaskBroadcasted
        {
            get { return this.broadcastTaskSubject; }
        }

        private List<BattleTask> requestedTasks = new List<BattleTask>();

        private float deltaTime;

        /// <summary>
        /// タスクをリクエストします.
        /// </summary>
        /// <param name="task"></param>
        public void Request(BattleTask task)
        {
            this.requestedTasks.Add(task);
        }

        /// <summary>
        /// タスク処理を発行します.
        /// </summary>
        /// <param name="task"></param>
        private void Broadcast(BattleTask task)
        {
            this.broadcastTaskSubject.OnNext(task);
        }

    }
}
