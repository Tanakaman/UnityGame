﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class CardOperator
    {
        public class Operation
        {
            /// <summary>
            /// カードを選択したときの処理を表します.
            /// </summary>
            public System.Action OnSelectBegan { get; set; }

            /// <summary>
            /// カードを離したときの処理を表します.
            /// </summary>
            public System.Action OnReleased { get; set; }
        }

        List<Operation> _operations = new List<Operation>();

        public List<Operation> Operations { get { return _operations; } }
    }
}
