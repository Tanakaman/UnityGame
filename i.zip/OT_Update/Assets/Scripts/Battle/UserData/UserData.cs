﻿namespace OT.Battle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UniRx;
    using UnityEngine;

    /// <summary>
    /// 
    /// </summary>
    public class UserData
    {
        private bool isMyTurn = false;

        private int currentMana = 0;

        private int maxMana = 0;

        private Constant.Battle.PlayerSide playerSide = Constant.Battle.PlayerSide.Player1;

        private int lifePoint = 0;

        private List<BattleCard> handCardList = new List<BattleCard>();

        /// <summary>
        /// 手札のカードを表します.
        /// </summary>
        public List<BattleCard> HandCardList { get => handCardList; set => handCardList = value; }


        public bool IsMyTurn
        {
            get => isMyTurn; set => isMyTurn = value;
        }

        public int CurrentMana
        {
            get => currentMana;
            set
            {
                currentMana = value;

                OnChangedMana();
            }
        }

        public int MaxMana
        {
            get => maxMana;

            set
            {
                maxMana = value;

                OnChangedMana();
            }
        }

        public Constant.Battle.PlayerSide Side { get => playerSide; set => playerSide = value; }

        public int LifePoint
        {
            get => lifePoint;

            set
            {
                lifePoint = value;

                OnChangedLife();
            }
        }

        public BattleCard Draw()
        {
            BattleCard drawCard = null;

            if (this.playerSide == Constant.Battle.PlayerSide.Player1)
            {
                drawCard = BattleInstance.Instance.PlayerDeck.Draw();

                this.AddCard(drawCard);
            }
            else
            {
                drawCard = BattleInstance.Instance.EnemyDeck.Draw();

                this.AddCard(drawCard);
            }
            return drawCard;
        }

        /// <summary>
        /// カードを手札に加えます.
        /// </summary>
        /// <param name="target"></param>
        public void AddCard(BattleCard target)
        {
            this.handCardList.Add(target);

            OnChangedCardNum(target);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        public void RemoveCard(BattleCard target)
        {
            this.handCardList.Remove(target);

            OnChangedCardNum(target);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        private void OnChangedCardNum(BattleCard target)
        {
            var inst = BattleInstance.Instance;

            var argment = new PlayerStatusArgment(
                       Constant.Battle.PlayerEventType.HandCardNumChanged,
                       target.HasPlayer,
                       handCardList.Count,
                       0);

            inst.BattleEvents.PlayerEventSubject.Send(argment);
        }


        private void OnChangedLife()
        {
            var arg = new PlayerStatusArgment(
                Constant.Battle.PlayerEventType.LifeChanged,
                this.playerSide,
                this.lifePoint,
                Constant.Battle.LifeMax);

            BattleInstance
                .Instance
                .BattleEvents
                .PlayerEventSubject
                .Send(arg);
        }

        private void OnChangedMana()
        {
#if DEBUG_LOG
            Debug.Log("[UserData] マナの量が変化しました => " + this.CurrentMana.ToString());
#endif

            var arg = new PlayerStatusArgment(
                Constant.Battle.PlayerEventType.ManaChanged,
                this.playerSide,
                this.currentMana,
                this.maxMana);

            BattleInstance
                .Instance
                .BattleEvents
                .PlayerEventSubject
                .Send(arg);
        }
    }
}
