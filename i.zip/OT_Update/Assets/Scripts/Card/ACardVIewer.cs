﻿namespace OT
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;
    using UnityEngine.UI;
    using UniRx;

    public abstract class ACardViewer : MonoBehaviour
    {
        public abstract void Setup(CardStatus target);

        public abstract Image CharacterImage { get; }
    }
}
