﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class Card
    {
        /// <summary>
        /// カードのDBのIDを表します.
        /// </summary>
        public long CardId { get; set; }

        /// <summary>
        /// カードの種類を表します.
        /// </summary>
        public Constant.Common.CardType Type { get; set; }

        /// <summary>
        /// カード名を表します.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// カードの説明を表します.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// カードのコストを表します.
        /// </summary>
        public long Cost { get; set; }

        /// <summary>
        /// 参照する画像のIDを表します.
        /// </summary>
        public long ImageId { get; set; }

        /// <summary>
        /// カードの座標や位置を表します.
        /// </summary>
        public int Index { get; set; }

        /// <summary>
        /// 体力を表します.
        /// </summary>
        public long HP { get; set; }

        /// <summary>
        /// 攻撃力を表します.
        /// </summary>
        public long Power { get; set; }

        /// <summary>
        /// 移動速度を表します.
        /// </summary>
        public long Speed { get; set; }

        /// <summary>
        /// 攻撃範囲を表します.
        /// </summary>
        public long Range { get; set; }

        /// <summary>
        /// 効果を所持しているかを表します.
        /// </summary>
        public bool HaveEffect { get { return EffectIdSet != null && EffectIdSet.Count > 0; } }

        /// <summary>
        /// このカードがもつ効果を表します.
        /// </summary>
        private List<long> effectIdSet = new List<long>();

        /// <summary>
        /// このカードがもつ効果を表します.
        /// </summary>
        public List<long> EffectIdSet
        {
            get { return effectIdSet; }
        }

        /// <summary>
        /// このカードがもつ効果を表します.
        /// </summary>
        public List<CardEffect> EffectSet { get; set; }

        /// <summary>
        /// モンスターカードの初期化を行います.
        /// </summary>
        /// <param name="masterData"></param>
        public void InitializeMonster(Model.Master.Monster masterData)
        {
            this.Name = masterData.Name;
            this.Cost = masterData.Cost;
            this.ImageId = masterData.ImageId;
            this.Type = Constant.Common.CardType.Monster;
            this.CardId = masterData.Id;
            this.HP = masterData.HP;
            this.Power = masterData.Power;
            this.Speed = masterData.Speed;
            this.Range = masterData.Range;
            //this.EffectIdSet = masterData.EffectSetId;
        }

        /// <summary>
        /// 呪文の初期化を行います.
        /// </summary>
        /// <param name="masterData"></param>
        public void InitializeSpell(Model.Master.Spell masterData)
        {
            this.Name = masterData.Name;
            this.Cost = masterData.Cost;
            //this.ImageId = masterData.ImageId;
            this.Type = Constant.Common.CardType.Spell;
            this.CardId = masterData.Id;
            this.ImageId = masterData.ImageId;
        }

        /// <summary>
        /// カード効果の初期化を行います.
        /// </summary>
        /// <param name="effects"></param>
        public void InitializeEffect(List<Model.Master.Effect> effects)
        {
            this.EffectSet = new List<CardEffect>();

            effects.ForEach(e =>
            {
                var effect = new CardEffect();
                effect.InitializeEffect(e);
                this.EffectSet.Add(effect);
            });
        }

        public override string ToString()
        {
            string str = string.Empty;

            Func<object, string> _ = new Func<object, string>(target =>
            {
                return target?.ToString();
            });

            str += "[CardId] : " + _(this.CardId);
            str += "[Type] : " + _(this.Type);
            str += "[Name] : " + _(this.Name);
            str += "[Cost] : " + _(this.Cost);
            str += "[ImageId] : " + _(this.ImageId);
            str += "[effectIdSet] : " + _(this.effectIdSet);

            return str;
        }

    }
}
