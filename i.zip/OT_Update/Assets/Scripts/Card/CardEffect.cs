﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class CardEffect
    {
        /// <summary>
        /// 効果のDBのIDを表します.
        /// </summary>
        public long EffectId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 効果発動タイミングを表します.
        /// </summary>
        public Constant.Battle.EffectTimingType TimingType { get; set; }

        /// <summary>
        /// 条件.
        /// </summary>
        public long ConditionType { get; set; }

        /// <summary>
        /// 条件.
        /// </summary>
        public string ConditionTarget { get; set; }

        /// <summary>
        /// コスト.
        /// </summary>
        public long Cost { get; set; }

        /// <summary>
        /// 効果持続ターン数.
        /// </summary>
        public long EffectiveTurn { get; set; }

        /// <summary>
        /// 効果を与える対象を表します.
        /// </summary>
        public Constant.Battle.EffectRangeType EffectiveRange { get; set; }

        /// <summary>
        /// 効果を与える対象を表します.
        /// </summary>
        public Constant.Battle.EffectRangeSide EffectiveRangeSide { get; set; }

        /// <summary>
        /// .
        /// </summary>
        public string RangeTarget { get; set; }

        /// <summary>
        /// カードの効果の種類を表します.
        /// </summary>
        public Constant.Battle.EffectType EffectType { get; set; }

        /// <summary>
        /// 効果量.
        /// </summary>
        public long Amount { get; set; }

        /// <summary>
        /// 効果回数.
        /// </summary>
        public long Times { get; set; }

        /// <summary>
        /// カードの初期化を行います.
        /// </summary>
        /// <param name="masterData"></param>
        public void InitializeEffect(Model.Master.Effect masterData)
        {
            this.EffectId = masterData.Id;
            this.Description = masterData.Description;
            this.TimingType = (Constant.Battle.EffectTimingType)masterData.TimingType;
            this.ConditionType = masterData.ConditionType;
            this.ConditionTarget = masterData.ConditionTarget;
            this.Cost = masterData.Cost;
            this.EffectiveTurn = masterData.EffectiveTurn;
            this.EffectiveRange = (Constant.Battle.EffectRangeType)masterData.EffectiveRange;
            this.EffectiveRangeSide = (Constant.Battle.EffectRangeSide)masterData.EffectiveRangeSide;
            this.RangeTarget = masterData.RangeTarget;
            this.EffectType = (Constant.Battle.EffectType)masterData.EffectType;
            this.Amount = masterData.Amount;
            this.Times = masterData.Times;
        }
    }
}
