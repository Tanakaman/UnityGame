﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UniRx;

    public class CardStatus
    {
        private BattleCard status = null;

        /// <summary>
        /// カードの内容を取得します.
        /// </summary>
        public BattleCard HasCard
        {
            get { return this.status; }
            set
            {
                this.status = value;

                this.cardSubject.OnNext(this.status);
            }
        }

        private Subject<BattleCard> cardSubject = new Subject<BattleCard>();

        /// <summary>
        /// カードの内容が変更されたときに購読される処理を取得します.
        /// </summary>
        public IObservable<BattleCard> OnCardChanged
        {
            get { return this.cardSubject; }
        }

    }
}
