﻿namespace OT
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;
    using UnityEngine.UI;
    using UniRx;

    public class HandCardViewer : ACardViewer
    {
        [SerializeField]
        Image characterImage;

        [SerializeField]
        Image frameImage;

        [SerializeField]
        Image backgroundImage;

        [SerializeField]
        Text costText;

        [SerializeField]
        Text powerText;

        [SerializeField]
        Text hitPointText;

        [SerializeField]
        Text rangeText;

        [SerializeField]
        Text speedText;

        [SerializeField]
        Text nameText;

        [SerializeField]
        Image reverseImage;

        Vector2 initialSize;

        public override Image CharacterImage { get => characterImage; }

        private void Awake()
        {
            var rectTransform = this.CharacterImage.rectTransform;
            this.initialSize = rectTransform.sizeDelta;

            // カードはデフォルト表にします.
            this.SetReverse(false);
        }

        public override void Setup(CardStatus target)
        {
            Card card = target.HasCard;

            this.SetCardStatus(card);

            target.OnCardChanged.Subscribe(_ =>
                {
                    this.SetCardStatus(_);
                });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isReverse"></param>
        public void SetReverse(bool isReverse)
        {
            this.reverseImage?.gameObject.SetActive(isReverse);

            this.characterImage.gameObject.SetActive(!isReverse);
            this.frameImage.gameObject.SetActive(!isReverse);
            this.backgroundImage.gameObject.SetActive(!isReverse);
        }

        public void SetCardStatus(Card card)
        {
            this.nameText.text = card.Name;
            this.costText.text = card.Cost.ToString();
            this.powerText.text = card.Power.ToString();
            this.rangeText.text = card.Range.ToString();
            this.hitPointText.text = card.HP.ToString();
            this.speedText.text = card.Speed.ToString();

            CardTextureFactory.AsyncCreate(
                card.ImageId,
                new Vector2(initialSize.x, initialSize.y),
                this.CharacterImage
                );
        }
    }
}
