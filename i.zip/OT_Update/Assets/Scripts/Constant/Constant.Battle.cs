﻿

namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public static partial class Constant
    {
        public static class Battle
        {
            public static int sizeX = 6;
            public static int sizeY = 6;

            public static readonly int LifeMax = 10;

            public enum PlayerSide
            {
                Player1,
                Player2,
                //Player3,
                //Player4,
                //GameMaster,
                Max,
            }

            /// <summary>
            /// 初期化フェイズの種類を表します.
            /// </summary>
            public enum InitializeType
            {
                FieldBegan,
                FieldFinished,
                SummonBegan,
                SummonFinished,
                HandBegan,
                HandFinished,
                PlayerDataBegan,
                PlayerDataFinished,
                Completed,
            }

            /// <summary>
            /// プレイヤーに関するデータのイベントの種類を表します.
            /// </summary>
            public enum PlayerEventType
            {
                ManaChanged,
                LifeChanged,
                HandCardNumChanged,
                DeckNumChanged,
                GraveyardNumChanged,
                UnavailableSummon,
                Summon,
            }

            /// <summary>
            /// フェイズの種類を表します.
            /// </summary>
            public enum PhaseType
            {
                None,

                /// <summary>
                /// プレイヤー初期化終了.
                /// </summary>
                PlayerInitialized,

                /// <summary>
                /// バトル初期化終了.
                /// </summary>
                BattleInitialized,

                /// <summary>
                /// バトル開始.
                /// </summary>
                InGameBegan,

                /// <summary>
                /// ターン開始.
                /// </summary>
                TurnBegan,

                /// <summary>
                /// リフレッシュフェイズ.
                /// </summary>
                RefreshBegan,

                /// <summary>
                /// ドローフェイズ.
                /// </summary>
                DrawBegan,

                /// <summary>
                /// メインフェイズ.
                /// </summary>
                MainBegan,

                /// <summary>
                /// ターン終了.
                /// </summary>
                TurnFinished,
            }

            /// <summary>
            /// カードの効果タイミングを表します.
            /// </summary>
            public enum CardEffectTiming
            {
                ExecueEffect,
                SelectedTarget,
            }

            /// <summary>
            /// 効果発動タイミングを表します.
            /// </summary>
            public enum EffectTimingType
            {
                None,
                Summoned,  // 1 : 召喚時（ファンファーレ）.
                Destroyed, // 2 : 破壊時（ラストワード）.
                Static, // 3: 永続.
                TurnBegin, // 4 : ターン開始時.
                TurnEnd, // 5 : ターンエンド時.
                Attacked, // 6 : 攻撃時.
                Defenced, // 7 : 防御時.
            }

            /// <summary>
            /// 
            /// </summary>
            public enum EffectRangeType : UInt32
            {
                None            = 0,
                Single          = 1 << 0, // 0 : 1体.
                Random          = 1 << 1, // 1 : ランダム.
                All             = 1 << 2, // 2 : 全体.
                Leader          = 1 << 3, // 3 : 自分のリーダー.
                EnemyLeader     = 1 << 4, // 4 : 敵のリーダー.
                WithoutSelf     = 1 << 5, // 5 : 自身を覗く.
            }

            /// <summary>
            /// 
            /// </summary>
            public enum EffectRangeSide
            {
                EnemySide,  // 0 : 敵側.
                SelfSide,   // 1 : 味方側.
                All,        // 2 : 全体.
            }

            public enum EffectType
            {
                None,
                Damage,         // 1 : ダメージを与える.
                Healing,        // 2 : 回復する.
                Draw,           // 3 : ドローする.
                HandDeath,      // 4 : ハンデス.
                Summon,         // 5 : 召喚.
                Destroy,        // 6 : 破壊.
                Bounce,         // 7 : バウンス.
                Banish,         // 8 : 除外.
                PowerUp,        // 9 : パワー上昇.
                DefenceUp,      // 10 : 防御上昇.
                Buff,           // 11 : バフ付与.
                Unbuff,         // 12 : バフ解除.
            }

        }
    }
}
