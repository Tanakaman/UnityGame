﻿

namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public static partial class Constant
    {
        public static class Common
        {
            public enum TimeScaleType
            {
                Player,
                UI,
                Max,
            }

            public enum CardType
            {
                None,
                Monster,
                Spell,
            }
        }
    }
}
