﻿namespace OT.DeveloperTools
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Yggdrasil;

    using UnityEngine;
    using UnityEngine.UI;

    /// <summary>
    /// 
    /// </summary>
    public static class DeveloperToolInitializer
    {
        public static IWidget CreateWidget(string label, System.Action resolve)
        {
            return new Widget(
                    (widget) =>
                    {
                        if (GUILayout.Button(label))
                        {
                            if (resolve != null) resolve();
                        }
                    }
                );
        }
        
        public static void Initialize()
        {
            var container = Valhalla.GameObject.AddComponent<WidgetContainer>();

            container.IsExpectedToBeNot(null);

            int i = 0;


            // 任意のキーに子ウィジェットを追加していきます.
            // root
            //   - child 
            //     - child
            //   - child 
            container.Root["Battle"] = CreateWidget(
                "ダメージスキルを発動する",
                () =>
                {

                });

            container.Root["Battle"] = CreateWidget(
                "test2",
                () =>
                {
                    var p = GameObject.Find("Field");
                    //FieldCreator.Create(p.transform, Constant.Battle.sizeX, Constant.Battle.sizeY, new Vector3(2.1f, 1.4f, 1));
                });

            container.Root["Battle"] = CreateWidget(
                "test3",
                () =>
                {
                    var loadedObj = Battle.FieldCreator.LoadObject();
                    var createdObj = Battle.FieldCreator.CreateObject(loadedObj);
                    createdObj.transform.SetParent(Battle.BattleInstance.Instance.MiddlegroundUITransform);
                    createdObj.transform.localPosition = Vector3.zero;

                    createdObj.GetComponentInChildren<UnityEngine.UI.Image>().color = Color.red;
                    createdObj.transform.SetAsLastSibling();

                    createdObj.AddComponent<UI.TweenPosition>().To(new Vector3(100, 0, 0), 5);
                    //createdObj.AddComponent<UI.TweenPosition>().To(new Vector3(100, 0, 0), 5).SetDelay(6);
                    createdObj.AddComponent<UI.TweenPosition>().To(new Vector3(-100, 0, 0), 5).SetDelay(7);
                });
        }
    }
}
