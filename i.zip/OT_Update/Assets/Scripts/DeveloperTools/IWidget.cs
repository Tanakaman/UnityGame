﻿namespace OT.DeveloperTools
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// 
    /// </summary>
    public interface IWidget
    {
        IWidget this[string name] { get; set; }

        void View();

        void OnExecute();

        /// <summary>
        /// ウィジェットを追加します.
        /// </summary>
        /// <param name="widget"></param>
        void Add(IWidget widget);

        bool IsEnabled { get; set; }

        bool IsEnabledChildren { get; set; }
    }
}
