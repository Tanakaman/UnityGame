﻿namespace OT.DeveloperTools
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;

    /// <summary>
    /// 
    /// </summary>
    public class Widget : IWidget
    {
        /// <summary>
        /// 自身が内包する<see cref="Widget"/>を表します.
        /// </summary>
        System.Action<IWidget> onResolve = null;
        
        /// <summary>
        /// 子として処理する<see cref="Widget"/>を表します.
        /// </summary>
        Dictionary<string, IWidget> children = new Dictionary<string, IWidget>();

        /// <summary>
        /// 自身が表示する<see cref="IWidget"/>
        /// </summary>
        List<IWidget> viewList = new List<IWidget>();

        public bool IsEnabled { get; set; }

        public bool IsEnabledChildren { get; set; }

        public IWidget this[string name]
        {
            get
            {
                if(children.ContainsKey(name) == false)
                {
                    // トグルによる所持Widgetの表示切り替え.
                    var widget = new Widget((x) =>
                    {
                        x.IsEnabled = GUILayout.Toggle(x.IsEnabled, name);
                    });

                    children.Add(name, widget);
                }
                return children[name];
            }
            set
            {
                this[name].Add(value);
            }
        }
        
        public Widget(System.Action<IWidget> resolve)
        {
            this.onResolve = resolve;
        }

        public void Add(IWidget target)
        {
            this.viewList.Add(target);
        }

        public void OnExecute()
        {
            this.onResolve(this);
        }

        public void View()
        {
            this.OnExecute();

            if (IsEnabled == false) return;
            
            foreach (var elem in this.viewList)
            {
                elem.OnExecute();
            }

            if (this.children.Count == 0) return;

            GUILayout.BeginHorizontal();
            GUILayout.BeginVertical("box");
            {
                //if (IsEnabledChildren == false) return;
                {
                    foreach (var child in children)
                    {
                        child.Value.View();
                    }
                }
            }
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }
    }
}
