﻿namespace OT.DeveloperTools
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;

    /// <summary>
    /// 
    /// </summary>
    public class WidgetContainer : MonoBehaviour
    {
        Widget root = null;

        public IWidget Root { get { return this.root; } }

        bool isEnabled = false;

        private void Awake()
        {
            // とりあえず空の親を作成します.
            this.root = new Widget( (x) => { } );
            {
                this.root.IsEnabled = true;
                this.root.IsEnabledChildren = true;
            }

        }

        public static void AutoResize(int screenWidth, int screenHeight)
        {
            Vector2 resizeRatio = new Vector2((float)Screen.width / screenWidth, (float)Screen.height / screenHeight);
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(resizeRatio.x, resizeRatio.y, 1.0f));
        }

        private void OnGUI()
        {
            AutoResize(1280, 720);

            this.isEnabled = GUILayout.Toggle(this.isEnabled, "On / Off");

            if (this.isEnabled != false)
            {
                GUILayout.Window(
                    -1,
                    new Rect(0, 8, Screen.width * 1280 / Screen.width, Screen.height * 720 / Screen.height),
                    (x) =>
                    {
                        this.root.View();
                    },
                    "DeveloperTools"
                    );
            }

            GUI.matrix = Matrix4x4.identity;
        }

    }
}
