﻿namespace OT.Event
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UniRx;

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class EventSender<T>
    {
        Subject<T> eventSubject = new Subject<T>();

        public IObservable<T> OnEvent { get { return this.eventSubject; } }

        public void Send(T Value)
        {
            eventSubject.OnNext(Value);
        }
    }

    /*
    public interface IEvent<T>
    {
        void Execute(T Value);
    }

    public class Event<T> : IEvent<T>
    {
        public Event(Action<T> execute)
        {
            this.OnExecuted = () =>
            {
                execute(this.Value);
            };
        }

        public Event(Action execute)
        {
            this.OnExecuted = () => 
            {
                execute();
            };
        }

        private Action OnExecuted { get; set; }

        private T Value { get; set; }

        public void Execute(T Value)
        {
            this.Value = Value;

            if(this.OnExecuted != null)
                this.OnExecuted();
        }
    }

    public interface IReceiver<T>
    {
        IEvent<T> Handler { get; }
    }

    public class Receiver<T> : IReceiver<T>
    {
        public Receiver(IEvent<T> e)
        {
            this.Handler = e;
        }

        public IEvent<T> Handler { get; private set; }
    }

    public class EventSender<T>
    {
        protected List<IReceiver<T>> receivers = new List<IReceiver<T>>();

        protected void Broadcast(T Value)
        {
            receivers.ForEach(x =>
            {
                x.Handler.Execute(Value);
            });
        }

        public IReceiver<T> AddReceiver(IReceiver<T> receiver)
        {
            if(ContainsReceiver(receiver)) return receiver;

            this.receivers.Add(receiver);

            return receiver;
        }

        public IReceiver<T> AddReceiver(Action<T> onExecute)
        {
            IEvent<T> e = new Event<T>(onExecute);

            IReceiver<T> receiver = new Receiver<T>(e);

            return AddReceiver(receiver);
        }

        public IReceiver<T> AddReceiver(Action onExecute)
        {
            IEvent<T> e = new Event<T>(onExecute);

            IReceiver<T> receiver = new Receiver<T>(e);

            return AddReceiver(receiver);
        }

        public void RemoveReceiver(IReceiver<T> receiver)
        {
            if(!ContainsReceiver(receiver)) return;

            this.receivers.Remove(receiver);
        }

        public bool ContainsReceiver(IReceiver<T> receiver)
        {
            return this.receivers.Contains(receiver);
        }

        /// <summary>
        /// <paramref name="Value"/> の値を受信者へ通知します.
        /// </summary>
        /// <param name="Value"></param>
        public void Send(T Value)
        {
            this.Broadcast(Value);

        }
    }
    */

    /// <summary>
    /// 削除を検討.
    /// </summary>
    /*
    public class GenericEventSender
    {
        public class EmptyType
        {
        }

        List<IReceiver<EmptyType>> receivers = new List<IReceiver<EmptyType>>();

        private void Broadcast()
        {
            receivers.ForEach( x =>
            {
                x.Handler.Execute(new EmptyType());
            });
        }

        public IReceiver<EmptyType> AddReceiver(IReceiver<EmptyType> receiver)
        {
            if(ContainsReceiver(receiver)) return receiver;

            this.receivers.Add(receiver);

            return receiver;
        }

        public IReceiver<EmptyType> AddReceiver(Action onExecute)
        {
            IEvent<EmptyType> e = new Event<EmptyType>(onExecute);

            IReceiver<EmptyType> receiver = new Receiver<EmptyType>(e);

            return AddReceiver(receiver);
        }

        public void RemoveReceiver(IReceiver<EmptyType> receiver)
        {
            if(!ContainsReceiver(receiver)) return;

            this.receivers.Remove(receiver);
        }

        public bool ContainsReceiver(IReceiver<EmptyType> receiver)
        {
            return this.receivers.Contains(receiver);
        }

        /// <summary>
        /// <paramref name="Value"/> の値を受信者へ通知します.
        /// </summary>
        /// <param name="Value"></param>
        public void Send()
        {
            this.Broadcast();
        }
    }
    */
}
