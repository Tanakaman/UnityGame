﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UnityEngine;

    public static class TimeScaler
    {
        private static float[] timeScale = new float[(int)Constant.Common.TimeScaleType.Max]
        {
            1.0f,
            1.0f,
        };

        public static float GetDeltaTime(Constant.Common.TimeScaleType type)
        {
            return GetTimeScale(type) * Time.deltaTime;
        }

        public static float GetTimeScale(Constant.Common.TimeScaleType type)
        {
            return timeScale[(int)type] * Time.timeScale;
        }

        public static void SetTimeScale(Constant.Common.TimeScaleType type, float nextTimeScale)
        {
            timeScale[(int)type] = nextTimeScale;
        }

    }
}
