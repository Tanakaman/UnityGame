﻿/// <summary>
/// Colum.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Model
{
    using System;

    /// <summary>
    /// カラムを表すクラスです.
    /// </summary>
	public class Colum
	{
        public Colum()
        {

        }

        public Colum(string name, object data)
        {
            this.Name = name;
            this.Data = data;
        }

        /// <summary>
        /// カラム名.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 対象の値.
        /// </summary>
        public object Data { get; set; }
	}
}
