﻿/// <summary>
/// IDeserializer.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Model
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    /// <summary>
    /// カラムのデシリアライズを提供するインタフェースです.
    /// </summary>
	public interface IDeserializer
	{
        void Deserialize(IDictionary param);
	}
}
