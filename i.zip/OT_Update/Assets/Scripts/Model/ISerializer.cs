﻿/// <summary>
/// ISerializer.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Model
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// カラムのシリアライズ化を提供するインタフェースです.
    /// </summary>
	public interface ISerializer
	{
        List<Colum> Serialize();
	}
}
