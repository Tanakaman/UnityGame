﻿namespace Model.Master
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class Card : IMasterData
    {
        public long Id { get; private set; }

        public long CardType { get; private set; }

        public long TargetId { get; private set; }

        public void Deserialize(IDictionary param)
        {
            this.Id = param["id"].ToLong();
            this.CardType = param["card_type"].ToLong();
            this.TargetId = param["target_id"].ToLong();
        }

        public List<Colum> Serialize()
        {
            return new List<Colum>()
            {
                new Colum("id",             this.Id),
                new Colum("card_type",      this.CardType),
                new Colum("target_id",      this.TargetId),
            };
        }
    }
}
