﻿namespace Model.Master
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class Effect : IMasterData
    {
        public long Id { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public string Description { get; private set; }

        /// <summary>
        /// 発動タイミング.
        /// </summary>
        public long TimingType { get; private set; }

        /// <summary>
        /// 条件.
        /// </summary>
        public long ConditionType { get; private set; }

        /// <summary>
        /// 条件.
        /// </summary>
        public string ConditionTarget { get; private set; }

        /// <summary>
        /// コスト.
        /// </summary>
        public long Cost { get; private set; }

        /// <summary>
        /// 効果持続ターン数.
        /// </summary>
        public long EffectiveTurn { get; private set; }

        /// <summary>
        /// 効果有効範囲.
        /// </summary>
        public long EffectiveRange { get; private set; }

        /// <summary>
        /// 効果有効範囲.
        /// </summary>
        public long EffectiveRangeSide { get; private set; }

        /// <summary>
        /// .
        /// </summary>
        public string RangeTarget { get; private set; }

        /// <summary>
        /// 効果.
        /// </summary>
        public long EffectType { get; private set; }

        /// <summary>
        /// 効果量.
        /// </summary>
        public long Amount { get; private set; }

        /// <summary>
        /// 効果回数.
        /// </summary>
        public long Times { get; private set; }

        public void Deserialize(IDictionary param)
        {
            this.Id = param["id"].ToLong();
            this.Description = param["description"].ToString();
            this.TimingType = param["timing_type"].ToLong();
            this.ConditionType = param["condition_type"].ToLong();
            this.ConditionTarget = param["condition_target"].ToString();
            this.Cost = param["cost"].ToLong();
            this.EffectiveTurn = param["effective_turn"].ToLong();
            this.EffectiveRange = param["effective_range"].ToLong();
            this.EffectiveRangeSide = param["effective_range_side"].ToLong();
            this.RangeTarget = param["range_target"].ToString();
            this.EffectType = param["effect_type"].ToLong();
            this.Amount = param["amount"].ToLong();
            this.Times = param["times"].ToLong();
        }

        public List<Colum> Serialize()
        {
            return new List<Colum>()
            {
                new Colum("id",             this.Id),
            };
        }
    }
}
