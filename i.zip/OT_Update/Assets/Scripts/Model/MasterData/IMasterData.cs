﻿/// <summary>
/// IMasterData.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Model.Master
{
    using System.Collections;
    using System.Collections.Generic;

    /// <summary>
    /// マスタデータの基底クラスを表します.
    /// </summary>
    /// <remarks>シリアライズとデシリアライズをサポートします.</remarks>
	public interface IMasterData:
        IDeserializer,
        ISerializer
	{
        long Id { get; }
	}
}
