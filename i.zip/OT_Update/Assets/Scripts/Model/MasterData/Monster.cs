﻿namespace Model.Master
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class Monster : IMasterData
    {
        public long Id { get; private set; }

        public long CharacterId { get; private set; }

        public string Name { get; private set; }

        public long Rarity { get; private set; }

        public long Cost { get; private set; }

        public long HP { get; private set; }

        public long Power { get; private set; }

        public long Speed { get; private set; }

        public long Range { get; private set; }

        public long EffectSetId { get; private set; }

        public long ImageId { get; private set; }

        public void Deserialize(IDictionary param)
        {
            this.Id = param["id"].ToLong();
            this.CharacterId = param["character_id"].ToLong();
            this.Name = param["name"].ToString();
            this.Rarity = param["rarity"].ToLong();
            this.Cost = param["cost"].ToLong();
            this.HP = param["hp"].ToLong();
            this.Power = param["power"].ToLong();
            this.Speed = param["speed"].ToLong();
            this.Range = param["range"].ToLong();
            this.EffectSetId = param["effect_set_id"].ToLong();
            this.ImageId = param["image_id"].ToLong();
        }

        public List<Colum> Serialize()
        {
            return new List<Colum>()
            {
                new Colum("id",             this.Id),
                new Colum("name",           this.Name),
                new Colum("hp",           this.HP),
                new Colum("power",           this.Power),
            };
        }
    }
}
