﻿#define ENABLE_CACHE

namespace Model.Master
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using Yggdrasil;
    using UnityEngine;

    using System.Text;
    using System.IO;

    using MiniJSON;

    /// <summary>
    /// 
    /// </summary>
	public static class RequestHelper
    {
        #region Public Methods

        /// <summary>
        /// <see cref="Model.Master.Effect"/>を取得します.
        /// </summary>
        /// <param name="id">取得するID.<see cref="null"/>を指定すると全て取得します.</param>
        /// <param name="onFetched">取得時のコールバック処理.</param>
        public static void GetMasterDataEffect(long id, Action<Effect> onFetched)
        {
            GetMasterDataEffect(new List<long> { id }, (x) => onFetched(x[0]));
        }

        /// <summary>
        /// <see cref="Model.Master.Effect"/>を取得します.
        /// </summary>
        /// <param name="id">取得するID.<see cref="null"/>を指定すると全て取得します.</param>
        /// <param name="onFetched">取得時のコールバック処理.</param>
        public static void GetMasterDataEffect(List<long> id, Action<List<Effect>> onFetched)
        {
            var promise = GetMasterData<Effect>(id, onFetched);

            promise.Then(result =>
                {
                    onFetched(result);

                    return result;
                })
                .Catch(reason =>
                {
#if DEBUG_LOG
                    Debug.LogError("Model.Effect の取得に失敗しました. => " + reason);
#endif
                });
        }

        /// <summary>
        /// <see cref="Model.Master.Monster"/>を取得します.
        /// </summary>
        /// <param name="id">取得するID.<see cref="null"/>を指定すると全て取得します.</param>
        /// <param name="onFetched">取得時のコールバック処理.</param>
        public static void GetMasterDataMonster(long id, Action<Monster> onFetched)
        {
            GetMasterDataMonster(new List<long> { id }, (x) => onFetched(x[0]));
        }

        /// <summary>
        /// <see cref="Model.Master.Monster"/>を取得します.
        /// </summary>
        /// <param name="id">取得するID.<see cref="null"/>を指定すると全て取得します.</param>
        /// <param name="onFetched">取得時のコールバック処理.</param>
        public static void GetMasterDataMonster(List<long> id, Action<List<Monster>> onFetched)
        {
            var promise = GetMasterData<Monster>(id, onFetched);

            promise.Then(result =>
                {
                    onFetched(result);

                    return result;
                })
                .Catch(reason =>
                {
#if DEBUG_LOG
                    Debug.LogError("Model.Monster の取得に失敗しました. => " + reason);
#endif
                });
        }

        /// <summary>
        /// <see cref="Model.Master.Spell"/>を取得します.
        /// </summary>
        /// <param name="id">取得するID.<see cref="null"/>を指定すると全て取得します.</param>
        /// <param name="onFetched">取得時のコールバック処理.</param>
        public static void GetMasterDataSpell(long id, Action<Spell> onFetched)
        {
            GetMasterDataSpell(new List<long> { id }, (x) => onFetched(x[0]));
        }

        /// <summary>
        /// <see cref="Model.Master.Spell"/>を取得します.
        /// </summary>
        /// <param name="id">取得するID.<see cref="null"/>を指定すると全て取得します.</param>
        /// <param name="onFetched">取得時のコールバック処理.</param>
        public static void GetMasterDataSpell(List<long> id, Action<List<Spell>> onFetched)
        {
            var promise = GetMasterData<Spell>(id, onFetched);

            promise.Then(result =>
            {
                onFetched(result);

                return result;
            })
                .Catch(reason =>
                {
#if DEBUG_LOG
                    Debug.LogError("Model.Spell の取得に失敗しました. => " + reason);
#endif
                });
        }

        #endregion

        /// <summary>
        /// マスタデータを取得する処理を提供します.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <param name="onFetched"></param>
        /// <returns></returns>
        private static Promise<List<T>> GetMasterData<T>(List<long> id, Action<List<T>> onFetched)where T : IMasterData, new ()
        {
            return new Promise<List<T>>( ( resolve, reject ) =>
                {
                    // Assetsの場所.
                    var _dataPath = Application.streamingAssetsPath + "/DataBase/" + typeof(T).Name + ".json";
#if ENABLE_CACHE
                    if (cachedMasterDictionary.ContainsKey(_dataPath))
                    {
                        var _result = cachedMasterDictionary[_dataPath] as List<T>;
                        _result.IsExpectedToBeNot(null);

                        resolve(Filter(_result, id));

                        // キャッシュしていたデータを渡して終了.
                        return;
                    }
#endif
                    // UTF8形式でデータを読み込む.
                    StreamReader sr = new StreamReader(_dataPath, Encoding.UTF8);

                    // 文字列として全てコピー.
                    var source = sr.ReadToEnd();

                    // ファイルは直ぐ閉じる.
                    sr.Close();
                    
                    List<T> result = new List<T>();

                    // インタフェースを通してデータを初期化する.
                    {
                        var table = Json.Deserialize(source) as IList;
                        foreach (var t in table)
                        {
                            T master = new T();

                            master.Deserialize(t as IDictionary);

                            result.Add(master);
                        }
                    }

#if ENABLE_CACHE
                    // キャッシュしておくことで同様のパスのときは、
                    // 次回から高速に渡すことができる.
                    cachedMasterDictionary.Add(_dataPath, result);
#endif
                    resolve(Filter(result, id));
                });
        }

        private static Dictionary<string, IList> cachedMasterDictionary = new Dictionary<string, IList>();

        /// <summary>
        /// マスタ取得時の指定IDが存在するかどうかでフィルタリングします.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="result"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        private static List<T> Filter<T>(List<T> result, List<long> id) where T : IMasterData
        {
            if (id == null)
            {
                return result;
            }
            else
            {
                return result.FindAll(x => id.Contains(x.Id));
            }
        }
	}
}
