﻿namespace Model.Master
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class Spell : IMasterData
    {
        public long Id { get; private set; }

        public string Name { get; private set; }

        public long Rarity { get; private set; }

        public long Cost { get; private set; }

        public List<long> EffectSetId { get; private set; }

        public long ImageId { get; private set; }

        public void Deserialize(IDictionary param)
        {
            this.Id = param["id"].ToLong();
            this.Name = param["name"].ToString();
            this.Rarity = param["rarity"].ToLong();
            this.Cost = param["cost"].ToLong();
            this.EffectSetId = param["effect_set_id"] as List<long>;
            this.ImageId = param["image_id"].ToLong();
        }

        public List<Colum> Serialize()
        {
            return new List<Colum>()
            {
                new Colum("id",             this.Id),
                new Colum("name",           this.Name),
            };
        }
    }
}
