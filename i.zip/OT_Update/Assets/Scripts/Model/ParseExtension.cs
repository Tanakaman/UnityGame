﻿/// <summary>
/// ParseExtension.cs
/// <author>Masahiro Sugikawa</author>
/// </summary>
namespace Model
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

	public static class ParseExtension
	{
        /// <summary>
        /// <see cref="long"/>型に変換します.
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public static long ToLong(this object target)
        {
            long _result = 0;

            if (target.GetType() == typeof(string))
            {
                long.TryParse(target as string, out _result);
            }
            else
            {
                _result = (long)target;
            }

            return _result;
        }

        /// <summary>
        /// <see cref="int"/>型に変換します.
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public static int ToInt(this object target)
        {
            int _result = 0;

            if (target.GetType() == typeof(string))
            {
                int.TryParse(target as string, out _result);
            }
            else
            {
                _result = (int)target;
            }

            return _result;
        }

        /// <summary>
        /// <see cref="float"/>型に変換します.
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public static float ToFloat(this object target)
        {
            float _result = 0;

            if (target.GetType() == typeof(string))
            {
                float.TryParse(target as string, out _result);
            }
            else
            {
                _result = (int)target;
            }

            return _result;
        }
        
        /// <summary>
        /// <see cref="double"/>型に変換します.
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public static double ToDouble(this object target)
        {
            double _result = 0;

            if (target.GetType() == typeof(string))
            {
                double.TryParse(target as string, out _result);
            }
            else
            {
                _result = (int)target;
            }

            return _result;
        }
	}
}
