﻿namespace OT.Title
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UnityEngine;
    using Yggdrasil;

    public class Login : MonoBehaviour
    {
        public void Request()
        {
            Fader.Fadeout(0.5f, () =>
            {
                Sleipnir.Navigate("Menu");
            });
        }
    }
}
