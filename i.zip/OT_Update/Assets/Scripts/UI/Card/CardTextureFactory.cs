﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;
    using Yggdrasil;

    /// <summary>
    /// 
    /// </summary>
    public static class CardTextureFactory
    {
        public static void AsyncCreate(long cardId, Vector2 imageSize, Image characterImage)
        {
            characterImage.IsExpectedToBeNot(null);

            // 自動的にロードした画像を設定するようにします.
            Action<Texture2D> onFinished = (tex) =>
            {
                Sprite sprite = null;

                if (tex == null)
                {
#if DEBUG_LOG
                    Debug.LogWarning("[CardTextureFactory] 不正なカードIDです. " + cardId.ToString());
#endif

                    return;
                }
                else
                {
                    sprite = Sprite.Create(
                                        tex,
                                        new Rect(0, 0, tex.width, tex.height),
                                        Vector2.zero
                                        );

                    characterImage.sprite = sprite;
                }
                
                var rectTrans = characterImage.transform as RectTransform;
                rectTrans.IsExpectedToBeNot(null);

                float calcWidth  = tex.width;
                float calcHeight = tex.height;

                // 縦と横で大きさを比較し、枠をはみ出ていたら収めます.
                {
                    if (calcWidth > calcHeight)
                    {
                        float ratio = (imageSize.x / tex.width);
                        calcWidth = calcWidth * ratio;
                        calcHeight = calcHeight * ratio;
                    }
                    else
                    {
                        float ratio = (imageSize.y / tex.height);
                        calcWidth = calcWidth * ratio;
                        calcHeight = calcHeight * ratio;
                    }
                }

                rectTrans.sizeDelta = new Vector2(calcWidth, calcHeight);
            };

            AsyncCreate(cardId, onFinished);
        }

        public static void AsyncCreate(long cardId, Action<Texture2D> onFinished)
        {
            GameObject loader = new GameObject("TextureLoader");

            string path = "Image/Monster/mon_" + string.Format("{0:D5}", cardId);

            loader
                .AddComponent<CardTextureLoader>()
                .Request(path, onFinished);
        }
    }
}
