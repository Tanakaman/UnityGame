﻿namespace OT
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using Yggdrasil;

    /// <summary>
    /// 
    /// </summary>
    public class CardTextureLoader : MonoBehaviour
    {
        private bool isAutoDestroy = true;

        public bool IsAutoDestroy { get => isAutoDestroy; set => isAutoDestroy = value; }

        public void Request(string path, Action<Texture2D> onResolve)
        {
            StartCoroutine(this.LoadRoutine(path, onResolve));
        }

        IEnumerator LoadRoutine(string path, Action<Texture2D> onResolve)
        {
            var loadedObj = Resources.Load<Texture2D>(path);

            onResolve(loadedObj);

            if(IsAutoDestroy)
            {
                Destroy(this.gameObject);
            }

            yield return null;
        }
    }
}
