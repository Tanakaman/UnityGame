﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;
    using Yggdrasil;

    /// <summary>
    /// 
    /// </summary>
    public class UICard : MonoBehaviour
    {
        [SerializeField]
        Image characterImage;

        [SerializeField]
        Text nameText;

        [SerializeField]
        Text costText;

        [SerializeField]
        Text detailText;

        [SerializeField]
        Text powerText;

        [SerializeField]
        Text hitPointText;

        [SerializeField]
        Text speedText;

        [SerializeField]
        Text rangeText;
        
        public void SetCardStatus(Card card)
        {
            this.nameText.text = card.Name;
            this.detailText.text = card.Description;
            this.costText.text = card.Cost.ToString();
            this.powerText.text = card.Power.ToString();
            this.rangeText.text = card.Range.ToString();
            this.hitPointText.text = card.HP.ToString();
            this.speedText.text = card.Speed.ToString();

            //CardTextureFactory.AsyncCreate(
            //    card.ImageId,
            //    new Vector2(initialSize.x, initialSize.y),
            //    this.CharacterImage
            //    );
        }
    }
}
