﻿namespace OT
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;    
    using UnityEngine;
    using UnityEngine.UI;
    using Yggdrasil;

    /// <summary>
    /// 画面のフェード処理を提供します.
    /// </summary>
    public class Fader : MonoBehaviour
    {
        [SerializeField]
        Image refScreenFilter;

        static Fader _statcFader;

        [SerializeField]
        float currentDelay = 0;

        [SerializeField]
        float delay = 0;

        /// <summary>
        /// 
        /// </summary>
        [SerializeField]
        float currentDuration = 0;

        /// <summary>
        /// 
        /// </summary>
        [SerializeField]
        float duration = 0;

        /// <summary>
        /// 終わったときのコールバック処理を表します.
        /// </summary>
        System.Action onFinished;

        /// <summary>
        /// フェードアウトするかどうかを表します.
        /// フェードアウト＝画面を暗くします.
        /// </summary>
        [SerializeField]
        bool isFadeOut = true;
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="duration"></param>
        /// <param name="onFinished"></param>
        public static void Fadeout(float duration, System.Action onFinished)
        {
            statcFader.Set(true, duration, onFinished);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="duration"></param>
        /// <param name="onFinished"></param>
        public static void Fadein(float duration, System.Action onFinished)
        {
            statcFader.Set(false, duration, onFinished);
        }

        static Fader statcFader
        {
            get
            {
                if(_statcFader == null)
                    _statcFader = new GameObject("Fader").AddComponent<Fader>();

                return _statcFader;
            }

            set
            {
                _statcFader = value;
            }
        }

        private void OnDestroy()
        {
            _statcFader = null;
        }

        void Awake()
        {
            //if(statcFader != this)
            //{
            //    Debug.LogError("Not found instance");
            //}

            _statcFader = this;

            this.refScreenFilter = this.gameObject.RequireComponent<Image>();
            {
                //refScreenFilter.rectTransform.localScale = new Vector3(1920 / 100.0f, 1080 / 100.0f);
            }
        }

        private void Update()
        {
            if(currentDuration >= duration)
            {
                if(this.onFinished != null)
                {
                    this.onFinished();
                    this.onFinished = null;
                }

                return;
            }

            if(currentDelay < delay)
            {
                currentDelay += Time.deltaTime;
            }

            if (currentDelay >= delay)
            {
                currentDuration += Time.deltaTime;
            }

            float alpha = isFadeOut ? (this.currentDuration / this.duration) : 1 - (this.currentDuration / this.duration);
            alpha = Mathf.Clamp(alpha, 0, 1);

            this.refScreenFilter.color = new Color(0, 0, 0, alpha);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="duration"></param>
        /// <param name="onFinished"></param>
        void Set(bool isFadeOut, float duration, System.Action onFinished)
        {
            this.isFadeOut = isFadeOut;
            this.duration = duration;
            this.currentDuration = 0;
            this.onFinished = onFinished;
        }

    }
}
