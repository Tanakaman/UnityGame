﻿namespace OT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEngine;
    using Yggdrasil;

    /// <summary>
    /// 
    /// </summary>
    [RequireComponent(typeof(UnityEngine.UI.Outline))]
    public class UIText : UnityEngine.UI.Text
    {

    }
}
