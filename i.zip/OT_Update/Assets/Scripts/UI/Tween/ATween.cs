﻿namespace OT.UI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UnityEngine;

    public abstract class ATween : MonoBehaviour
    {
        protected Action<float> OnUpdateDelta { get; set; }

        protected Action OnInitialize { get; set; }

        [SerializeField]
        protected float delayTime;

        [SerializeField]
        protected bool isAutoStart = false;

        public Action OnFinished { get; set; }

        protected void Awake()
        {
            this.OnUpdateDelta = this.UpdateDelta;
        }

        protected void Update()
        {
            var deltaTime = TimeScaler.GetDeltaTime(Constant.Common.TimeScaleType.UI);
            if(this.delayTime > 0)
            {
                this.delayTime -= deltaTime;

                if (this.delayTime > 0) return;
            }

            if(this.OnInitialize != null)
            {
                this.OnInitialize();
                this.OnInitialize = null;
            }

            if(this.OnUpdateDelta != null)
            {
                this.OnUpdateDelta(deltaTime);
            }
        }

        protected abstract void UpdateDelta(float deltaTime);

        public ATween SetDelay(float delay)
        {
            this.delayTime = delay;

            return this;
        }

    }
}
