﻿namespace OT.UI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UnityEngine;
    using UnityEngine.UI;

    public class TweenAlpha : ATween
    {
        [SerializeField]
        float from;

        [SerializeField]
        float to;

        [SerializeField]
        float interval;

        [SerializeField]
        float duration;

        [SerializeField]
        bool isLoop = false;

        [SerializeField]
        float currentIntervalTime;

        [SerializeField]
        float currentDuration;

        /// <summary>
        /// 透過のベクトルを表します.
        /// </summary>
        float vector = 1;

        Graphic cachedGraphic;

        Action<float> Updater { get; set; }

        /// <summary>
        /// ループするかどうかを設定します.
        /// </summary>
        public bool IsLoop { get => isLoop; set => isLoop = value; }

        protected void Start()
        {
            this.cachedGraphic = this.GetComponent<Graphic>();

            if (this.isAutoStart)
            {
                this.Play(this.from, this.to, this.interval, this.duration);
                this.isAutoStart = false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void SwitchVector()
        {
            this.vector *= -1;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="delta"></param>
        protected override void UpdateDelta(float delta)
        {
            if (this.Updater == null) return;

            System.Action onFinishedUpdate = () =>
            {
                if (this.IsLoop)
                {
                    this.SwitchVector();
                }

                if (this.duration < 0) return;

                if (this.currentDuration >= this.duration)
                {
                    this.Updater = null;

                    if (OnFinished != null) OnFinished();
                }
            };

            this.currentIntervalTime += delta * vector;
            this.currentDuration += delta;
            
            if(this.currentDuration > this.duration)
            {
                this.currentDuration = this.duration;
            }

            if (this.vector > 0)
            {
                if(this.currentIntervalTime > this.interval)
                {
                    this.currentIntervalTime = this.interval;

                    onFinishedUpdate();
                }
                else
                {

                }
            }
            else
            {
                if(this.currentIntervalTime < 0)
                {
                    this.currentIntervalTime = 0;

                    onFinishedUpdate();
                }
                else
                {

                }
            }

            float alpha = this.currentIntervalTime / this.interval;

            if(this.Updater != null ) this.Updater(alpha);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="alpha"></param>
        /// <returns></returns>
        public TweenAlpha RevertOnFinished(float alpha = 1)
        {
            this.OnFinished += () =>
            {
                var color = this.cachedGraphic.color;
                color.a = alpha;
                this.cachedGraphic.color = color;
            };
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public TweenAlpha DestroyOnFinished()
        {
            this.OnFinished += () =>
            {
                Destroy(this);
            };
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public TweenAlpha Play(float interval, float duration, bool isLoop)
        {
            this.OnInitialize = () =>
            {
                this.from = this.cachedGraphic ? this.cachedGraphic.color.a : 0;
                this.to = 0;
                this.interval = interval;
                this.duration = duration;
                this.isLoop = isLoop;

                this.SetUpdateFilter(this.from, this.to, this.interval, this.duration);
            };

            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="to"></param>
        /// <returns></returns>
        public TweenAlpha Play(float to, float duration)
        {
            this.OnInitialize = () =>
            {
                this.from       = this.cachedGraphic ? this.cachedGraphic.color.a : 0; 
                this.to         = to;
                this.interval   = duration;
                this.duration   = duration;

                this.SetUpdateFilter(this.from, this.to, this.interval, this.duration);
            };

            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="interval"></param>
        /// <returns></returns>
        public TweenAlpha Play(float from, float to, float interval, float duration)
        {
            this.OnInitialize = () =>
            {
                this.from      = from;
                this.to        = to;
                this.interval  = interval;
                this.duration  = duration;

                this.SetUpdateFilter(this.from, this.to, this.interval, this.duration);
            };

            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inFrom"></param>
        /// <param name="inTo"></param>
        /// <param name="interval"></param>
        private void SetUpdateFilter(float inFrom, float inTo, float interval, float duration)
        {
            Updater = (alpha) =>
            {
                if (alpha >= 1)
                {
                    var color               = this.cachedGraphic.color;
                    color.a                 = to;
                    this.cachedGraphic.color  = color;
                }
                else
                {
                    var color               = this.cachedGraphic.color;
                    color.a                 = Mathf.Lerp(from, to, alpha);
                    this.cachedGraphic.color  = color;
                }
            };
        }
    }
}
