﻿namespace OT.UI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using UnityEngine;

    public class TweenPosition : ATween
    {
        [SerializeField]
        Vector3 from;
        [SerializeField]
        Vector3 to;
        [SerializeField]
        float lerpTime;

        float currentDeltaTime;

        Action<float> Updater { get; set; }


        protected void Start()
        {
            if (this.isAutoStart)
            {
                this.FromTo(from, to, lerpTime);
                this.isAutoStart = false;
            }
        }

        protected override void UpdateDelta(float delta)
        {
            if (this.Updater == null) return;

            currentDeltaTime += delta;
            currentDeltaTime = currentDeltaTime > this.lerpTime ? this.lerpTime : currentDeltaTime;

            float alpha = currentDeltaTime / this.lerpTime;

            this.Updater(alpha);

            if (alpha < 1) return;

            this.Updater = null;

            if (OnFinished != null) OnFinished();
        }

        public TweenPosition To(Vector3 _to, float time)
        {
            this.OnInitialize = () =>
            {
                this.from = this.transform.localPosition;
                this.to = _to;
                this.lerpTime = time;

                this.SetUpdateFilterLocal(from, to, time);
            };

            return this;
        }

        public TweenPosition FromTo(Vector3 _from, Vector3 _to, float time)
        {
            this.OnInitialize = () =>
            {
                this.from      = _from;
                this.transform.localPosition = this.from;

                this.to        = _to;
                this.lerpTime = time;

                this.SetUpdateFilterLocal(from, to, time);
            };

            return this;
        }

        public TweenPosition FromToWorld(Vector3 _from, Vector3 _to, float time)
        {
            this.OnInitialize = () =>
            {
                this.from      = _from;
                this.transform.localPosition = this.from;

                this.to        = _to;
                this.lerpTime = time;

                this.SetUpdateFilterWorld(from, to, time);
            };

            return this;
        }

        private void SetUpdateFilterLocal(Vector3 _from, Vector3 _to, float time)
        {
            Updater = (alpha) =>
            {
                if (alpha >= 1)
                {
                    this.gameObject.transform.localPosition = to;
                }
                else
                {
                    this.gameObject.transform.localPosition = Vector3.Lerp(from, to, alpha);
                }
            };
        }

        private void SetUpdateFilterWorld(Vector3 _from, Vector3 _to, float time)
        {
            Updater = (alpha) =>
            {
                if (alpha >= 1)
                {
                    this.gameObject.transform.localPosition = to;
                }
                else
                {
                    this.gameObject.transform.localPosition = Vector3.Lerp(from, to, alpha);
                }
            };
        }

    }
}
